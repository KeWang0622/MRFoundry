# M4Raw source attribution

The frozen k-space subset and derived scientific images in `assets/` originate from:

Mengye Lyu, Lifeng Mei, Shoujin Huang, Sixing Liu, Yi Li, Kexin Yang, Yilong Liu, Yu Dong, Linzheng Dong and Ed X. Wu. **M4Raw: A multi-contrast, multi-repetition, multi-channel MRI k-space dataset for low-field MRI research**, version 1.6, 2023.

- Dataset: <https://doi.org/10.5281/zenodo.8056074>
- Paper: <https://doi.org/10.1038/s41597-023-02181-4>
- License: **Creative Commons Attribution 4.0 International (CC BY 4.0)**, <https://creativecommons.org/licenses/by/4.0/>
- Legal terms: <https://creativecommons.org/licenses/by/4.0/legalcode>
- Original dataset member: `multicoil_val/2022061203_T201.h5`, zero-based slice 8, four coils.

Changes from the original dataset: the retained complex k-space subset was normalized by the source RSS maximum in the recorded experiment. The four brain PNGs are retained outputs from that experiment, including zero-filled and L1-wavelet reconstructions. This figure adds a declared grayscale log-magnitude display of the frozen k-space array and editable labels, exact mask geometry and workflow annotations. No new reconstruction, per-image intensity adjustment, anatomical flip or generative image enhancement was performed for this figure. Exact bounds, normalization and provenance hashes are in `figure4-data.json` and `provenance.json`.

This attribution describes the dataset-derived material and does not imply endorsement by the dataset authors.
