#!/usr/bin/env python3
"""Reuse Figure 1's original human portraits; preserve every other native object."""
from pathlib import Path
import argparse,hashlib,json,re,shutil,zipfile
PAT=re.compile(rb'<p:(sp|pic|cxnSp)\b.*?</p:\1>',re.S)
CROPS={'laptop':[1302,5371,68099,54102],'review':[1953,53223,68099,8691]}
SPECS={1:[],2:[{'role':'laptop','ids':list(range(30,63)),'x':2.085,'y':1.13,'w':.36,'old':[2.14,1.14,.25,.32]},{'role':'review','ids':list(range(135,168)),'x':5.75,'y':2.14,'w':.40,'old':[5.82,2.16,.27,.34]}],3:[{'role':'laptop','ids':[3,4],'x':.12,'y':.405,'w':.42,'old':[.225,.505,.20,.27]}],4:[{'role':'laptop','ids':[3,4],'x':.24,'y':.74,'w':.82,'old':[.45,.95,.40,.54]}],5:[{'role':'laptop','ids':[7,8],'x':.14,'y':1.105,'w':.38,'old':[.28,1.14,.22,.315]}]}
def sha(b):return hashlib.sha256(b).hexdigest()
def parts(p):
 with zipfile.ZipFile(p) as z:return {n:z.read(n) for n in z.namelist()}
def shape_id(b):return int(re.search(rb'<p:cNvPr\s+id="(\d+)"',b).group(1))
def placements(n):
 out=[]
 for spec in SPECS[n]:
  q=dict(spec);l,t,r,b=CROPS[q['role']];q['crop_ltrb_100000']=[l,t,r,b];q['h']=q['w']*(100000-t-b)*1024/((100000-l-r)*1536)
  q['bounds_emu']=[round(q[k]*914400) for k in ['x','y','w','h']];q['picture_shape_id']=q['ids'][0]
  # Exact union of the new picture and old stroked glyph, including one point for stroke.
  x,y,w,h=q['old'];m=1/72;left=min(q['x'],x-m);top=min(q['y'],y-m);right=max(q['x']+q['w'],x+w+m);bottom=max(q['y']+q['h'],y+h+m)
  q['overlay_region_in_top_left']=[left,top,right-left,bottom-top];out.append(q)
 return out
def pic(q):
 x,y,w,h=q['bounds_emu'];l,t,r,b=q['crop_ltrb_100000'];i=q['picture_shape_id']
 return f'<p:pic><p:nvPicPr><p:cNvPr id="{i}" name="Figure 1 researcher — {q["role"]}" descr="Original Figure 1 researcher illustration, native crop; illustrative role only."/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="rIdMRFoundryResearcher53"/><a:srcRect l="{l}" t="{t}" r="{r}" b="{b}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></p:spPr></p:pic>'.encode()
def patch(src,dst,n,asset):
 src=Path(src);dst=Path(dst);dst.parent.mkdir(parents=True,exist_ok=True);old=parts(src);new=dict(old);ps=placements(n);removed=[i for q in ps for i in q['ids']]
 if n==1:shutil.copyfile(src,dst)
 else:
  objects={shape_id(m.group()):m.group() for m in PAT.finditer(old['ppt/slides/slide1.xml'])};assert all(i in objects for i in removed)
  replacements={q['ids'][0]:pic(q) for q in ps}
  new['ppt/slides/slide1.xml']=PAT.sub(lambda m:replacements.get(shape_id(m.group()),b'') if shape_id(m.group()) in removed else m.group(),old['ppt/slides/slide1.xml'])
  relkey='ppt/slides/_rels/slide1.xml.rels';rel=b'<Relationship Id="rIdMRFoundryResearcher53" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/mrfoundry-researcher-original.png"/>'
  assert b'rIdMRFoundryResearcher53' not in old[relkey];new[relkey]=old[relkey].replace(b'</Relationships>',rel+b'</Relationships>')
  ct='[Content_Types].xml'
  if not re.search(rb'<Default[^>]*Extension="png"',new[ct]):new[ct]=new[ct].replace(b'</Types>',b'<Default Extension="png" ContentType="image/png"/></Types>')
  new['ppt/media/mrfoundry-researcher-original.png']=Path(asset).read_bytes()
  with zipfile.ZipFile(src) as zin,zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED) as zout:
   for zi in zin.infolist():zout.writestr(zi,new[zi.filename])
   zi=zipfile.ZipInfo('ppt/media/mrfoundry-researcher-original.png',(2026,11,4,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zout.writestr(zi,new[zi.filename])
 final=parts(dst);changed=[k for k in old if old[k]!=final[k]];added=[k for k in final if k not in old]
 assert set(changed)<= {'ppt/slides/slide1.xml','ppt/slides/_rels/slide1.xml.rels','[Content_Types].xml'}
 before={shape_id(m.group()):m.group() for m in PAT.finditer(old['ppt/slides/slide1.xml'])};after={shape_id(m.group()):m.group() for m in PAT.finditer(final['ppt/slides/slide1.xml'])}
 assert all(v==after[k] for k,v in before.items() if k not in removed)
 assert re.findall(rb'<a:t>.*?</a:t>',old['ppt/slides/slide1.xml'])==re.findall(rb'<a:t>.*?</a:t>',final['ppt/slides/slide1.xml'])
 return {'revision':'v53','figure':n,'source_name':src.name,'source_sha256':sha(src.read_bytes()),'pptx_sha256':sha(dst.read_bytes()),'scope':'Reuse Figure 1 researcher illustrations in human roles only; preserve existing agent and brand artwork.','researcher_asset_sha256':sha(Path(asset).read_bytes()) if n!=1 else None,'researcher_asset_origin':'Figure 1 embedded image2.png/image4.png; unchanged contact-sheet bytes and original native crop rectangles.','agent_artwork':'Original generated MRI character with laptop' if n==1 else 'Original native editable AI-chip symbol(s)','agent_artwork_restored_from_baseline':True,'agent_artwork_byte_identical':True,'brand_mascot_only':True,'brand_mascot_occurrences':1 if n==1 else 0,'restored_agent_occurrences':2 if n==5 else 1,'removed_avatar_shape_ids':removed,'inserted_avatar_shape_ids':[q['picture_shape_id'] for q in ps],'removed_researcher_shape_ids':removed,'inserted_researcher_shape_ids':[q['picture_shape_id'] for q in ps],'placements':ps,'changed_zip_members':changed,'added_zip_members':added,'non_avatar_objects_byte_identical':True,'non_researcher_objects_byte_identical':True,'existing_non_avatar_media_byte_identical':True,'all_existing_media_byte_identical':True,'human_avatars_unchanged':n==1,'scientific_data_changed':False,'text_change':'All original slide text, including researcher labels and AI lettering, preserved.','native_visual_review':'pending'}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--figure',type=int,required=True);p.add_argument('--asset',type=Path,required=True);a=p.parse_args();print(json.dumps(patch(a.source,a.output,a.figure,a.asset),indent=2))
