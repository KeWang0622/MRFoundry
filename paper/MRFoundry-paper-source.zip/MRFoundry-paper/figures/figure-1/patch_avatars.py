#!/usr/bin/env python3
"""Lossless non-avatar OOXML patch; approved raster replaces only listed avatar shapes.
Run with an original/baseline PPTX and packaged approved artwork. Native PDF export
must then be performed in PowerPoint (Best for printing), not an online service.
"""
from pathlib import Path
import argparse,base64,hashlib,json,re,zipfile,io,xml.etree.ElementTree as E
from PIL import Image
NS={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
MAP={2:[list(range(64,74))],3:[list(range(27,45))],4:[list(range(21,39))],5:[list(range(149,163)),list(range(184,198))]}
PAT=re.compile(rb'<p:(sp|pic|cxnSp)\b.*?</p:\1>',re.S)
def sha(b):return hashlib.sha256(b).hexdigest()
def parts(p):
 with zipfile.ZipFile(p) as z:return {n:z.read(n) for n in z.namelist()}
def shape_id(b):return int(re.search(rb'<p:cNvPr\s+id="(\d+)"',b).group(1))
def bounds(b):
 off=re.search(rb'<a:off x="(-?\d+)" y="(-?\d+)"',b);ex=re.search(rb'<a:ext cx="(\d+)" cy="(\d+)"',b)
 return tuple(map(int,off.groups()+ex.groups()))
def pic(sid,box,rid):
 x,y,w,h=box
 return f'<p:pic><p:nvPicPr><p:cNvPr id="{sid}" name="MRFoundry approved MRI mascot" descr="User-approved GPT Image mascot; illustrative agent identity, not scientific data."/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>'.encode()
def patch(src,dst,n,mascot,lockup=None,lockup_png=None):
 old=parts(src);new=dict(old);slide='ppt/slides/slide1.xml';removed=[];newids=[];slots=[]
 if n==1:
  new['ppt/media/image.svg']=Path(lockup).read_bytes();new['ppt/media/image.png']=Path(lockup_png).read_bytes()
  im=Image.open(mascot).convert('RGBA');oldim=Image.open(io.BytesIO(old['ppt/media/mrfoundry-mri-agent-v35.png']));im.thumbnail(oldim.size,Image.Resampling.LANCZOS);pad=Image.new('RGBA',oldim.size);pad.alpha_composite(im,((pad.width-im.width)//2,(pad.height-im.height)//2));buf=io.BytesIO();pad.save(buf,format='PNG');new['ppt/media/mrfoundry-mri-agent-v35.png']=buf.getvalue()
  unchanged_objects=True
 else:
  xml=old[slide];objects={shape_id(m.group()):m.group() for m in PAT.finditer(xml)};im=Image.open(mascot);ratio=im.width/im.height
  for ids in MAP[n]:
   boxes=[bounds(objects[sid]) for sid in ids];left=min(b[0] for b in boxes);top=min(b[1] for b in boxes);right=max(b[0]+b[2] for b in boxes);bottom=max(b[1]+b[3] for b in boxes)
   ow,oh=right-left,bottom-top;w=min(ow,oh*ratio);h=w/ratio;x=left+(ow-w)/2;y=top+(oh-h)/2;box=[round(v) for v in (x,y,w,h)]
   replacement=pic(ids[0],box,'rIdMRFoundryMascot51');xml=xml.replace(objects[ids[0]],replacement,1)
   for sid in ids[1:]:xml=xml.replace(objects[sid],b'',1)
   removed.extend(ids);newids.append(ids[0]);slots.append({'replaced_shape_ids':ids,'picture_box_emu':box})
  new[slide]=xml
  new['ppt/media/mrfoundry-mascot-v51.png']=Path(mascot).read_bytes()
  rp='ppt/slides/_rels/slide1.xml.rels';rel=b'<Relationship Id="rIdMRFoundryMascot51" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/mrfoundry-mascot-v51.png"/>';new[rp]=old[rp].replace(b'</Relationships>',rel+b'</Relationships>')
  ct='[Content_Types].xml'
  if b'Extension="png"' not in old[ct]:new[ct]=old[ct].replace(b'</Types>',b'<Default Extension="png" ContentType="image/png"/></Types>')
  before={k:v for k,v in objects.items() if k not in removed};after={shape_id(m.group()):m.group() for m in PAT.finditer(xml) if shape_id(m.group()) not in newids};unchanged_objects=before==after
  assert unchanged_objects
 dst=Path(dst);dst.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(src) as zin,zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED) as zout:
  for zi in zin.infolist():zout.writestr(zi,new.pop(zi.filename))
  for name,data in new.items():zout.writestr(name,data)
 final=parts(dst);changed=[k for k in old if old[k]!=final[k]];added=[k for k in final if k not in old]
 # All existing media except three approved F1 logo/mascot members remains exact.
 exceptions={'ppt/media/image.svg','ppt/media/image.png','ppt/media/mrfoundry-mri-agent-v35.png'} if n==1 else set()
 assert all(old[k]==final[k] for k in old if k.startswith('ppt/media/') and k not in exceptions)
 receipt={'revision':'v51','figure':n,'source_name':Path(src).name,'source_sha256':sha(Path(src).read_bytes()),'pptx_sha256':sha(dst.read_bytes()),'approved_mascot_input_sha256':sha(Path(mascot).read_bytes()),'scope':'MRFoundry agent avatars and Figure 1 header icon only; original wordmark preserved','removed_avatar_shape_ids':removed,'inserted_avatar_shape_ids':newids,'placements':slots,'changed_zip_members':changed,'added_zip_members':added,'non_avatar_objects_byte_identical':unchanged_objects,'existing_non_avatar_media_byte_identical':True,'human_avatars_unchanged':True,'scientific_data_changed':False,'text_change':'Only obsolete AI chip lettering removed; all non-avatar text unchanged.','native_visual_review':'pending','pdf_export':'not performed by the PPTX patch; run rebuild_avatar.py for the publication overlay'}
 (dst.parent/'avatar-change-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');return receipt
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--figure',type=int,required=True);p.add_argument('--mascot',type=Path,required=True);p.add_argument('--lockup',type=Path);p.add_argument('--lockup-png',type=Path);a=p.parse_args();print(json.dumps(patch(a.source,a.output,a.figure,a.mascot,a.lockup,a.lockup_png),indent=2))
