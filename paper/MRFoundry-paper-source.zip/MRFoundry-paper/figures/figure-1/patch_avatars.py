#!/usr/bin/env python3
"""Preserve the original agent artwork; update only Figure 1 brand media."""
from pathlib import Path
import argparse,hashlib,json,re,shutil,zipfile
MAP={2:[list(range(64,74))],3:[list(range(27,45))],4:[list(range(21,39))],5:[list(range(149,163)),list(range(184,198))]}
PAT=re.compile(rb'<p:(sp|pic|cxnSp)\b.*?</p:\1>',re.S)
def sha(b):return hashlib.sha256(b).hexdigest()
def parts(p):
 with zipfile.ZipFile(p) as z:return {n:z.read(n) for n in z.namelist()}
def shape_id(b):return int(re.search(rb'<p:cNvPr\s+id="(\d+)"',b).group(1))
def bounds(b):
 off=re.search(rb'<a:off x="(-?\d+)" y="(-?\d+)"',b);ex=re.search(rb'<a:ext cx="(\d+)" cy="(\d+)"',b)
 return tuple(map(int,off.groups()+ex.groups()))
def patch(src,dst,n,mascot,lockup=None,lockup_png=None):
 src=Path(src);dst=Path(dst);dst.parent.mkdir(parents=True,exist_ok=True);old=parts(src);new=dict(old)
 if n==1:
  new['ppt/media/image.svg']=Path(lockup).read_bytes();new['ppt/media/image.png']=Path(lockup_png).read_bytes()
  with zipfile.ZipFile(src) as zin,zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED) as zout:
   for zi in zin.infolist():zout.writestr(zi,new[zi.filename])
 else:shutil.copyfile(src,dst)
 final=parts(dst);changed=[k for k in old if old[k]!=final[k]]
 expected={'ppt/media/image.svg','ppt/media/image.png'} if n==1 else set()
 assert set(changed)==expected and set(old)==set(final)
 assert all(old[k]==final[k] for k in old if k not in expected)
 return {'revision':'v52','figure':n,'source_name':src.name,'source_sha256':sha(src.read_bytes()),'pptx_sha256':sha(dst.read_bytes()),'approved_mascot_input_sha256':sha(Path(mascot).read_bytes()),'scope':'Restore previous agent artwork; retain approved scanner mascot only as Figure 1 brand icon','agent_artwork':'Original generated MRI character with laptop' if n==1 else 'Original native editable AI-chip symbol(s)','agent_artwork_restored_from_baseline':True,'brand_mascot_only':True,'brand_mascot_occurrences':1 if n==1 else 0,'restored_agent_occurrences':2 if n==5 else 1,'removed_avatar_shape_ids':[],'inserted_avatar_shape_ids':[],'placements':[],'changed_zip_members':changed,'added_zip_members':[],'non_avatar_objects_byte_identical':True,'existing_non_avatar_media_byte_identical':True,'human_avatars_unchanged':True,'scientific_data_changed':False,'text_change':'All original slide text, including AI lettering, preserved.','native_visual_review':'pending','pdf_export':'Run rebuild_avatar.py for the preserved publication PDF.'}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--figure',type=int,required=True);p.add_argument('--mascot',type=Path,required=True);p.add_argument('--lockup',type=Path);p.add_argument('--lockup-png',type=Path);a=p.parse_args();print(json.dumps(patch(a.source,a.output,a.figure,a.mascot,a.lockup,a.lockup_png),indent=2))
