#!/usr/bin/env python3
"""Add only original Figure 1 human illustrations to the frozen publication PDF."""
from pathlib import Path
from pypdf import PdfReader,PdfWriter
from pypdf.generic import _base
# Retain precise baseline page dimensions; rounding can shift anti-aliased pixels.
_base.FLOAT_WRITE_PRECISION=16
from pypdf.generic import DecodedStreamObject,NameObject,DictionaryObject,ArrayObject,FloatObject
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
import base64,io,shutil,re
import patch_avatars as pa

def draw_crop(c,asset,q,W,H,sx,sy):
 x,y,w,h=[q['x']*sx,q['y']*sy,q['w']*sx,q['h']*sy];l,t,r,b=[v/100000 for v in q['crop_ltrb_100000']];fullw=w/(1-l-r);fullh=h/(1-t-b);bottom=H-y-h
 c.saveState();path=c.beginPath();path.rect(x,bottom,w,h);c.clipPath(path,stroke=0,fill=0);c.drawImage(ImageReader(asset),x-l*fullw,bottom-b*fullh,width=fullw,height=fullh);c.restoreState()
def overlay(srcpdf,out,n,asset,srcppt):
 srcpdf=Path(srcpdf);out=Path(out);reader=PdfReader(srcpdf);page=reader.pages[0];W,H=map(float,(page.mediabox.width,page.mediabox.height));regions=[]
 pres=pa.parts(srcppt)['ppt/presentation.xml'];cx,cy=map(int,re.search(rb'<p:sldSz[^>]*cx="(\d+)"[^>]*cy="(\d+)"',pres).groups());sx=W/(cx/914400);sy=H/(cy/914400)
 if n==1:shutil.copyfile(srcpdf,out)
 else:
  buf=io.BytesIO();c=canvas.Canvas(buf,pagesize=(W,H),invariant=True)
  for q in pa.placements(n):
   rx,ry,rw,rh=q['overlay_region_in_top_left'];x,y,w,h=rx*sx,ry*sy,rw*sx,rh*sy;c.setFillColor('white');c.rect(x,H-y-h,w,h,stroke=0,fill=1);regions.append([x,H-y-h,w,h]);draw_crop(c,asset,q,W,H,sx,sy)
  c.save();op=PdfReader(io.BytesIO(buf.getvalue())).pages[0];form=DecodedStreamObject();form.set_data(op['/Contents'].get_object().get_data());form.update({NameObject('/Type'):NameObject('/XObject'),NameObject('/Subtype'):NameObject('/Form'),NameObject('/BBox'):ArrayObject([FloatObject(0),FloatObject(0),FloatObject(W),FloatObject(H)]),NameObject('/Resources'):op['/Resources']})
  resources=page['/Resources'];xobjects=resources.get('/XObject',DictionaryObject()).get_object();resources[NameObject('/XObject')]=xobjects;xobjects[NameObject('/MRFoundryResearcherOverlay')]=form
  raw=page.get_contents().get_data();combined=DecodedStreamObject();combined.set_data(b'q\n'+raw+b'\nQ\nq\n/MRFoundryResearcherOverlay Do\nQ\n');page[NameObject('/Contents')]=combined;writer=PdfWriter();writer.add_page(page);writer.write(out)
 return {'source_pdf_sha256':pa.sha(srcpdf.read_bytes()),'pdf_sha256':pa.sha(out.read_bytes()),'page_size_pt':[W,H],'overlay_regions_pt':regions,'scientific_pdf_streams':'Retained verbatim; only human role illustrations receive an additive overlay.','baseline_pdf_byte_identical':srcpdf.read_bytes()==out.read_bytes()}
def svg_overlay(src,dst,n,asset):
 s=Path(src).read_text();groups=[];data=base64.b64encode(Path(asset).read_bytes()).decode()
 for j,q in enumerate(pa.placements(n)):
  ex,ey,ew,eh=[v*72 for v in q['overlay_region_in_top_left']];x,y,w,h=[v*72 for v in (q['x'],q['y'],q['w'],q['h'])];l,t,r,b=[v/100000 for v in q['crop_ltrb_100000']]
  groups.append(f'<g id="mrfoundry-researcher-v53-{j}"><rect x="{ex:.8f}" y="{ey:.8f}" width="{ew:.8f}" height="{eh:.8f}" fill="white"/><svg x="{x:.8f}" y="{y:.8f}" width="{w:.8f}" height="{h:.8f}" viewBox="{l*1536:.8f} {t*1024:.8f} {(1-l-r)*1536:.8f} {(1-t-b)*1024:.8f}" overflow="hidden" preserveAspectRatio="none"><image width="1536" height="1024" xlink:href="data:image/png;base64,{data}"/></svg></g>')
 Path(dst).write_text(s.replace('</svg>','\n'.join(groups)+'\n</svg>'))
