#!/usr/bin/env python3
"""Retain baseline publication PDFs; overlay Figure 1 brand icon only."""
from pathlib import Path
from pypdf import PdfReader,PdfWriter
from pypdf.generic import DecodedStreamObject,NameObject,DictionaryObject,ArrayObject,FloatObject
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
import argparse,io,json,re,shutil
import patch_avatars as pa

def overlay(srcpdf,srcppt,out,n,mascot,lockup=None):
 srcpdf=Path(srcpdf);out=Path(out);r=PdfReader(srcpdf);page=r.pages[0];W,H=map(float,(page.mediabox.width,page.mediabox.height));regions=[]
 if n==1:
  z=pa.parts(srcppt);pres=z['ppt/presentation.xml'];cx,cy=map(int,re.search(rb'<p:sldSz[^>]*cx="(\d+)"[^>]*cy="(\d+)"',pres).groups());sx,sy=W/cx,H/cy
  objects={pa.shape_id(m.group()):m.group() for m in pa.PAT.finditer(z['ppt/slides/slide1.xml'])}
  buf=io.BytesIO();c=canvas.Canvas(buf,pagesize=(W,H),invariant=True)
  x,y,w,h=pa.bounds(objects[9]);xp,yp,wp,hp=x*sx,H-(y+h)*sy,w*114/789.48*sx,h*sy
  c.setFillColor('white');c.rect(xp,yp,wp,hp,stroke=0,fill=1);regions.append([xp,yp,wp,hp])
  ix,iy,iw,ih=x+w*2/789.48,y+h*7/122,w*108/789.48,h*108/122
  c.drawImage(ImageReader(mascot),ix*sx,H-(iy+ih)*sy,width=iw*sx,height=ih*sy,mask='auto',preserveAspectRatio=True,anchor='c');c.save()
  op=PdfReader(io.BytesIO(buf.getvalue())).pages[0];form=DecodedStreamObject();form.set_data(op['/Contents'].get_object().get_data());form.update({NameObject('/Type'):NameObject('/XObject'),NameObject('/Subtype'):NameObject('/Form'),NameObject('/BBox'):ArrayObject([FloatObject(0),FloatObject(0),FloatObject(W),FloatObject(H)]),NameObject('/Resources'):op['/Resources']})
  resources=page['/Resources'];xobjects=resources.get('/XObject',DictionaryObject()).get_object();resources[NameObject('/XObject')]=xobjects;xobjects[NameObject('/MRFoundryBrandOverlay')]=form
  raw=page.get_contents().get_data();combined=DecodedStreamObject();combined.set_data(b'q\n'+raw+b'\nQ\nq\n/MRFoundryBrandOverlay Do\nQ\n');page[NameObject('/Contents')]=combined;wr=PdfWriter();wr.add_page(page);wr.write(out)
 else:shutil.copyfile(srcpdf,out)
 return {'source_pdf_sha256':pa.sha(srcpdf.read_bytes()),'pdf_sha256':pa.sha(out.read_bytes()),'page_size_pt':[W,H],'overlay_regions_pt':regions,'scientific_pdf_streams':'Retained verbatim; only Figure 1 header brand icon receives an additive overlay.' if n==1 else 'Entire publication PDF byte-identical to the packaged baseline.','baseline_pdf_byte_identical':srcpdf.read_bytes()==out.read_bytes()}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--source-pdf',type=Path,required=True);p.add_argument('--source-pptx',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--figure',type=int,required=True);p.add_argument('--mascot',type=Path,required=True);p.add_argument('--lockup',type=Path);a=p.parse_args();print(json.dumps(overlay(a.source_pdf,a.source_pptx,a.output,a.figure,a.mascot,a.lockup),indent=2))
