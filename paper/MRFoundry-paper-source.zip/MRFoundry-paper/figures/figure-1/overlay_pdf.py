#!/usr/bin/env python3
"""Preserve existing publication PDF and replace only avatar regions.
The original scientific vector/image streams remain unmodified. Overlay uses
approved raster art; native-PowerPoint export is inspected separately.
"""
from pathlib import Path
from pypdf import PdfReader,PdfWriter
from pypdf.generic import DecodedStreamObject,NameObject,DictionaryObject,ArrayObject,FloatObject
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
import argparse,io,json,zipfile,re,hashlib
import patch_avatars as pa

def overlay(srcpdf,srcppt,out,n,mascot,lockup):
 r=PdfReader(srcpdf);page=r.pages[0];W,H=map(float,(page.mediabox.width,page.mediabox.height));z=pa.parts(srcppt);pres=z['ppt/presentation.xml'];cx,cy=map(int,re.search(rb'<p:sldSz[^>]*cx="(\d+)"[^>]*cy="(\d+)"',pres).groups());sx,sy=W/cx,H/cy
 objects={pa.shape_id(m.group()):m.group() for m in pa.PAT.finditer(z['ppt/slides/slide1.xml'])}
 buf=io.BytesIO();c=canvas.Canvas(buf,pagesize=(W,H));regions=[]
 def paint(box,image,background='white',pad=.45,erase=True):
  x,y,w,h=box;xp,yp,wp,hp=x*sx,H-(y+h)*sy,w*sx,h*sy;c.setFillColor(background)
  if erase:c.rect(xp-pad,yp-pad,wp+2*pad,hp+2*pad,stroke=0,fill=1)
  c.drawImage(ImageReader(image),xp,yp,width=wp,height=hp,mask='auto',preserveAspectRatio=True,anchor='c');regions.append([xp-pad,yp-pad,wp+2*pad,hp+2*pad])
 if n==1:
  box=pa.bounds(objects[51]);paint(box,mascot)
  x,y,w,h=pa.bounds(objects[9]);# only icon slot; retain original outlined wordmark in PDF
  c.setFillColor('white');c.rect(x*sx,H-(y+h)*sy,w*114/789.48*sx,h*sy,stroke=0,fill=1)
  paint([x+w*2/789.48,y+h*7/122,w*108/789.48,h*108/122],mascot,pad=0)
 else:
  for ids in pa.MAP[n]:
   boxes=[pa.bounds(objects[i]) for i in ids];x=min(b[0] for b in boxes);y=min(b[1] for b in boxes);right=max(b[0]+b[2] for b in boxes);bottom=max(b[1]+b[3] for b in boxes)
   bg=('#f4f4f4' if ids[0]==149 else '#F6F2FA') if n==5 else 'white'
   # Erase only individual chip primitives, not the encompassing rectangle;
   # this leaves neighboring input arrowheads and the guidance document intact.
   c.setFillColor(bg)
   for bx,by,bw,bh in boxes:
    xp,yp,wp,hp=bx*sx,H-(by+bh)*sy,bw*sx,bh*sy
    c.rect(xp-1,yp-1,wp+2,hp+2,stroke=0,fill=1)
   paint([x,y,right-x,bottom-y],mascot,bg,erase=False)
 c.save();overlayr=PdfReader(io.BytesIO(buf.getvalue()));op=overlayr.pages[0];form=DecodedStreamObject();form.set_data(op['/Contents'].get_object().get_data());form.update({NameObject('/Type'):NameObject('/XObject'),NameObject('/Subtype'):NameObject('/Form'),NameObject('/BBox'):ArrayObject([FloatObject(0),FloatObject(0),FloatObject(W),FloatObject(H)]),NameObject('/Resources'):op['/Resources']})
 resources=page['/Resources'];xobjects=resources.get('/XObject',DictionaryObject()).get_object();resources[NameObject('/XObject')]=xobjects;xobjects[NameObject('/MRFoundryAvatarOverlay')]=form
 content=page['/Contents'].get_object();raw=b'\n'.join(x.get_object().get_data() for x in content) if isinstance(content,ArrayObject) else content.get_data();combined=DecodedStreamObject();combined.set_data(b'q\n'+raw+b'\nQ\nq\n/MRFoundryAvatarOverlay Do\nQ\n');page[NameObject('/Contents')]=combined;wr=PdfWriter();wr.add_page(page);wr.write(out)
 return {'source_pdf_sha256':pa.sha(Path(srcpdf).read_bytes()),'pdf_sha256':pa.sha(Path(out).read_bytes()),'page_size_pt':[W,H],'overlay_regions_pt':regions,'scientific_pdf_streams':'Retained; additive avatar-only overlay. Original source PDF is packaged.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--source-pdf',type=Path,required=True);p.add_argument('--source-pptx',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--figure',type=int,required=True);p.add_argument('--mascot',type=Path,required=True);p.add_argument('--lockup',type=Path);a=p.parse_args();print(json.dumps(overlay(a.source_pdf,a.source_pptx,a.output,a.figure,a.mascot,a.lockup),indent=2))
