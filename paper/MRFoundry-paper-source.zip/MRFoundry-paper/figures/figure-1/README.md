# Figure 1, revision 52

The previous MRI-character-with-laptop illustration is restored as the AI agent. The new approved scanner mascot remains only in the MRFoundry header brand icon. The original wordmark and all native slide objects are preserved.

Current files: `MRFoundry-Figure-1-v52.pptx`, `MRFoundry-Figure-1-v52.pdf`, `MRFoundry-Figure-1-v52.png`. Researcher avatars, scientific panels, labels, values, connectors and layout are unchanged. The reviewed current manuscript caption is in `caption.md` and the paper figure manifest; baseline speaker notes retain historical provenance.

## Portable rebuild

Install `requirements-avatar.txt` and Poppler, then run:

```sh
python3 rebuild_avatar.py --out rendered
```

Use `--pdftoppm /path/to/pdftoppm` if Poppler is not on PATH. All source inputs are packaged under `source/` and `assets/`; no external workspace input or model run is required. Existing legacy command names route to the same rebuild. `source/legacy-*` and `source/historical-*` retain historical evidence and are not the current renderer.

The publication PDF retains the original drawing stream and scientific image streams, with an additive overlay only at the header brand icon. It is not a fresh PowerPoint export.

`avatar-change-receipt.json` records restoration scope, hashes and preservation checks. `native-review.json` records separate native PowerPoint QA of the current PPTX.

No simulation, reconstruction, grading or agent comparison was rerun.
