#!/usr/bin/env python3
"""Rebuild the current figure with original agent artwork and brand-only mascot."""
from pathlib import Path
import argparse,json,shutil,subprocess
from patch_avatars import patch,sha
from overlay_pdf import overlay
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out','--output-root',type=Path,default=ROOT/'rendered');p.add_argument('--pdftoppm',default=shutil.which('pdftoppm'));p.add_argument('--render',action='store_true',help='Accepted for compatibility; PNG is always rendered when Poppler is available.');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 cfg=json.loads((ROOT/'avatar-config.json').read_text());n=cfg['figure'];stem=f'MRFoundry-Figure-{n}-v52';source=ROOT/'source/avatar-baseline.pptx';mascot=ROOT/'assets/mrfoundry-mascot-trimmed.png'
 receipt=patch(source,a.out/(stem+'.pptx'),n,mascot,ROOT/'assets/mrfoundry-logo-light.svg',ROOT/'assets/mrfoundry-logo-light.png')
 receipt['publication_pdf']=overlay(ROOT/'source/avatar-baseline.pdf',source,a.out/(stem+'.pdf'),n,mascot)
 receipt['pdf_export']='Preserved baseline PDF with brand-icon-only overlay.' if n==1 else 'Exact baseline publication PDF; no overlay or fresh scientific rendering.'
 if a.pdftoppm:
  subprocess.run([a.pdftoppm,'-singlefile','-scale-to','2000','-png',str(a.out/(stem+'.pdf')),str(a.out/stem)],check=True)
  receipt['png_sha256']=sha((a.out/(stem+'.png')).read_bytes())
 else:print('PPTX/PDF rebuilt; install Poppler or supply --pdftoppm to render PNG.')
 if n==5:shutil.copyfile(ROOT/'source/avatar-baseline.svg',a.out/(stem+'.svg'))
 (a.out/'avatar-change-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(str(a.out.resolve()))
if __name__=='__main__':main()
