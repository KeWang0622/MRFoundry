#!/usr/bin/env python3
"""Rebuild current native figure and publication exports from packaged frozen inputs."""
from pathlib import Path
import argparse,json,shutil,subprocess
from patch_avatars import patch,sha
from overlay_pdf import overlay,svg_overlay
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out','--output-root',type=Path,default=ROOT/'rendered');p.add_argument('--pdftoppm',default=shutil.which('pdftoppm'));p.add_argument('--render',action='store_true',help='Compatibility option; PNG is always rendered when Poppler is available.');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 cfg=json.loads((ROOT/'avatar-config.json').read_text());n=cfg['figure'];stem=f'MRFoundry-Figure-{n}-v53';source=ROOT/'source/researcher-baseline.pptx';asset=ROOT/'assets/researcher-original.png'
 receipt=patch(source,a.out/(stem+'.pptx'),n,asset);receipt['publication_pdf']=overlay(ROOT/'source/researcher-baseline.pdf',a.out/(stem+'.pdf'),n,asset,source);receipt['pdf_export']='Exact v52 Figure 1 publication PDF.' if n==1 else 'Frozen v52 PDF with localized human-illustration overlay only.'
 if a.pdftoppm:
  subprocess.run([a.pdftoppm,'-singlefile','-scale-to','2000','-png',str(a.out/(stem+'.pdf')),str(a.out/stem)],check=True);receipt['png_sha256']=sha((a.out/(stem+'.png')).read_bytes())
 else:print('PPTX/PDF rebuilt; install Poppler or supply --pdftoppm to render PNG.')
 if n==5:svg_overlay(ROOT/'source/researcher-baseline.svg',a.out/(stem+'.svg'),n,asset)
 (a.out/'avatar-change-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(str(a.out.resolve()))
if __name__=='__main__':main()
