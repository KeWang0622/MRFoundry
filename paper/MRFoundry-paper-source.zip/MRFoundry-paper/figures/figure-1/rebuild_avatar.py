#!/usr/bin/env python3
"""Rebuild the current avatar-only figure from packaged, frozen baseline sources."""
from pathlib import Path
import argparse,json,shutil,subprocess,base64,zipfile,re
from patch_avatars import patch,parts,PAT,shape_id,bounds,MAP
from overlay_pdf import overlay
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out','--output-root',type=Path,default=ROOT/'rendered');p.add_argument('--pdftoppm',default=shutil.which('pdftoppm'));p.add_argument('--render',action='store_true',help='Accepted for compatibility; PNG is always rendered when Poppler is available.');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 cfg=json.loads((ROOT/'avatar-config.json').read_text());n=cfg['figure'];stem=f'MRFoundry-Figure-{n}-v51';source=ROOT/'source/avatar-baseline.pptx';mascot=ROOT/'assets/mrfoundry-mascot-trimmed.png'
 receipt=patch(source,a.out/(stem+'.pptx'),n,mascot,ROOT/'assets/mrfoundry-logo-light.svg',ROOT/'assets/mrfoundry-logo-light.png')
 receipt['publication_pdf']=overlay(ROOT/'source/avatar-baseline.pdf',source,a.out/(stem+'.pdf'),n,mascot,None)
 receipt['pdf_export']='completed: localized publication PDF overlay; native PowerPoint inspection/export requires separate QA'
 if a.pdftoppm:subprocess.run([a.pdftoppm,'-singlefile','-scale-to','2000','-png',str(a.out/(stem+'.pdf')),str(a.out/stem)],check=True)
 else:print('PPTX/PDF rebuilt; install Poppler or supply --pdftoppm to render PNG.')
 if n==5:
  svg=(ROOT/'source/avatar-baseline.svg').read_text();old=parts(source);objects={shape_id(m.group()):m.group() for m in PAT.finditer(old['ppt/slides/slide1.xml'])};pres=old['ppt/presentation.xml'];cx,cy=map(int,re.search(rb'<p:sldSz[^>]*cx="(\d+)"[^>]*cy="(\d+)"',pres).groups());W,H=receipt['publication_pdf']['page_size_pt'];sx,sy=W/cx,H/cy;art=base64.b64encode(mascot.read_bytes()).decode();layer='<g id="mrfoundry-avatar-v51">'
  for ids in MAP[n]:
   boxes=[bounds(objects[i]) for i in ids];bg='#F4F4F4' if ids[0]==149 else '#F6F2FA';x=min(b[0] for b in boxes);y=min(b[1] for b in boxes);right=max(b[0]+b[2] for b in boxes);bottom=max(b[1]+b[3] for b in boxes)
   for bx,by,bw,bh in boxes:layer+=f'<rect x="{bx*sx-1}" y="{by*sy-1}" width="{bw*sx+2}" height="{bh*sy+2}" fill="{bg}"/>'
   layer+=f'<image x="{x*sx}" y="{y*sy}" width="{(right-x)*sx}" height="{(bottom-y)*sy}" preserveAspectRatio="xMidYMid meet" xlink:href="data:image/png;base64,{art}"/>'
  svg=svg.replace('</svg>',layer+'</g></svg>');(a.out/(stem+'.svg')).write_text(svg)
 (a.out/'avatar-change-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(str(a.out.resolve()))
if __name__=='__main__':main()
