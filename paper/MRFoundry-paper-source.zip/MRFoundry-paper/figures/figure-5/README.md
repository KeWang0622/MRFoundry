# Figure 5, revision 52

The original editable AI-chip symbols are restored for the agent roles. The complete PowerPoint and publication PDF are byte-identical to the packaged pre-mascot baseline.

Current files: `MRFoundry-Figure-5-v52.pptx`, `MRFoundry-Figure-5-v52.pdf`, `MRFoundry-Figure-5-v52.png` and `MRFoundry-Figure-5-v52.svg`. Researcher avatars, scientific panels, labels, values, connectors and layout are unchanged. The reviewed current manuscript caption is in `caption.md` and the paper figure manifest; baseline speaker notes retain historical provenance.

## Portable rebuild

Install `requirements-avatar.txt` and Poppler, then run:

```sh
python3 rebuild_avatar.py --out rendered
```

Use `--pdftoppm /path/to/pdftoppm` if Poppler is not on PATH. All source inputs are packaged under `source/` and `assets/`; no external workspace input or model run is required. Existing legacy command names route to the same rebuild. `source/legacy-*` and `source/historical-*` retain historical evidence and are not the current renderer.

The publication PDF is the exact baseline file. It is not re-exported, and the saved scientific rendering is unchanged.

`avatar-change-receipt.json` records restoration scope, hashes and preservation checks. `native-review.json` records separate native PowerPoint QA of the current PPTX.

No simulation, reconstruction, grading or agent comparison was rerun.
