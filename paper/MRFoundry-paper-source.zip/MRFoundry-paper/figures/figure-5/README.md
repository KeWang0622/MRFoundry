# Figure 5, revision 53

The human researcher now uses the original Figure 1 researcher-with-laptop illustration. The PNG bytes and original native crop rectangles are reused unchanged.

Current files: `MRFoundry-Figure-5-v53.pptx`, `MRFoundry-Figure-5-v53.pdf`, `MRFoundry-Figure-5-v53.png`, `MRFoundry-Figure-5-v53.svg`. Existing agent artwork, scientific panels, labels, values, connectors and all non-human native objects are unchanged. The current manuscript caption is in `caption.md` and the paper figure manifest; speaker notes retain historical provenance.

## Portable rebuild

Install `requirements-avatar.txt` and Poppler, then run:

```sh
python3 rebuild_avatar.py --out rendered
```

Use `--pdftoppm /path/to/pdftoppm` if Poppler is not on PATH. All inputs are packaged under `source/` and `assets/`; no external workspace inputs or model runs are required. Existing legacy command names route to this rebuild.

`source/researcher-baseline.*` contains the frozen figure used by the current rebuild. Superseded avatar baselines are omitted from this package; earlier artifacts remain in publication history. Historical scripts are not the current renderer. The original Figure 1 contact sheet is `assets/researcher-original.png`; PowerPoint uses native crop rectangles, the PDF uses document clipping, and Figure 5’s SVG uses an equivalent viewport. No portrait is regenerated or raster-edited.

Publication PDFs retain the frozen scientific drawing streams. Figures 2–5 add localized human-role overlays; Figure 1 is copied exactly. Independent native PowerPoint exports are used for visual QA only. Preserving precise PDF page dimensions avoids rounding-induced changes to scientific rasterization.

`avatar-change-receipt.json` records scope, object IDs, hashes, native crop rectangles and exact overlay regions. `native-review.json` records the actual PowerPoint inspection. Fresh isolated rebuilds reproduce all PPTX member bytes, PDF bytes/text geometry and PNG pixels. Pixels outside human-role regions are identical to v52.

No simulation, reconstruction, grading, statistical calculation or agent comparison was rerun.
