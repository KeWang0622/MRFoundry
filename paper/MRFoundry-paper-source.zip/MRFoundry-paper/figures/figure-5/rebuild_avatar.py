#!/usr/bin/env python3
"""Rebuild current native figure and publication exports from packaged frozen inputs."""
from pathlib import Path
import argparse,json,shutil,subprocess,zipfile
from patch_avatars import patch,sha
from overlay_pdf import overlay,svg_overlay
ROOT=Path(__file__).resolve().parent

def correct_notes(path):
 """Apply exact reviewed speaker-note corrections; preserve every visual part."""
 key='ppt/notesSlides/notesSlide1.xml'
 replacements=[(b'matched tools, inputs', b'matched host tools, inputs'), (b'The intervention comprises the skills and their project-level discovery instruction', b'The intervention comprises seven frozen skill packages, including helper scripts, and their project-level discovery instruction'), (b'All visible content is native editable PowerPoint text and vector geometry.', b'Text and diagram elements are native editable PowerPoint text and vector geometry; the researcher illustration is a raster image.'), (b'exact two-sided McNemar P = 0.0004 for Core and P = 0.061 for Hard.', b'secondary, unclustered exact two-sided McNemar P = 0.0004 for Core and P = 0.061 for Hard.')]
 with zipfile.ZipFile(path) as z:
  infos=z.infolist();before={i.filename:z.read(i) for i in infos}
 after=dict(before)
 for old,new in replacements:
  assert after[key].count(old)==1,'Expected one exact historical phrase in notes'
  after[key]=after[key].replace(old,new,1)
 prior_sha=sha(path.read_bytes());temporary=path.with_suffix('.notes.tmp')
 with zipfile.ZipFile(temporary,'w') as z:
  for info in infos:z.writestr(info,after[info.filename])
 temporary.replace(path)
 return {'revision':54,'scope':'Speaker notes only: matched host tools, frozen skill packages including helper scripts, accurate raster researcher provenance, and secondary unclustered McNemar qualification; no visual or scientific changes.','changed_member':key,'replacements':[{'before':old.decode(),'after':new.decode()} for old,new in replacements],'before_pptx_sha256':prior_sha,'after_pptx_sha256':sha(path.read_bytes()),'before_notes_sha256':sha(before[key]),'after_notes_sha256':sha(after[key]),'all_other_member_payloads_byte_identical':True,'historical_baseline_unchanged':True}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out','--output-root',type=Path,default=ROOT/'rendered');p.add_argument('--pdftoppm',default=shutil.which('pdftoppm'));p.add_argument('--render',action='store_true',help='Compatibility option; PNG is always rendered when Poppler is available.');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 cfg=json.loads((ROOT/'avatar-config.json').read_text());n=cfg['figure'];stem=f'MRFoundry-Figure-{n}-v53';source=ROOT/'source/researcher-baseline.pptx';asset=ROOT/'assets/researcher-original.png'
 receipt=patch(source,a.out/(stem+'.pptx'),n,asset);receipt['notes_revision_v54']=correct_notes(a.out/(stem+'.pptx'));receipt['pptx_sha256']=sha((a.out/(stem+'.pptx')).read_bytes());receipt['changed_zip_members'].append('ppt/notesSlides/notesSlide1.xml');receipt['publication_pdf']=overlay(ROOT/'source/researcher-baseline.pdf',a.out/(stem+'.pdf'),n,asset,source);receipt['pdf_export']='Exact v52 Figure 1 publication PDF.' if n==1 else 'Frozen v52 PDF with localized human-illustration overlay only.'
 if a.pdftoppm:
  subprocess.run([a.pdftoppm,'-singlefile','-scale-to','2000','-png',str(a.out/(stem+'.pdf')),str(a.out/stem)],check=True);receipt['png_sha256']=sha((a.out/(stem+'.png')).read_bytes())
 else:print('PPTX/PDF rebuilt; install Poppler or supply --pdftoppm to render PNG.')
 if n==5:svg_overlay(ROOT/'source/researcher-baseline.svg',a.out/(stem+'.svg'),n,asset)
 (a.out/'avatar-change-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(str(a.out.resolve()))
if __name__=='__main__':main()
