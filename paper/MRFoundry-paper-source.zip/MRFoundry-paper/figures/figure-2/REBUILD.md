# Current figure rebuild

See [README.md](README.md). Run `python3 rebuild_avatar.py --out rendered`; `--pdftoppm` selects a local Poppler executable. The original agent artwork is retained, with scanner mascot branding only in Figure 1.
