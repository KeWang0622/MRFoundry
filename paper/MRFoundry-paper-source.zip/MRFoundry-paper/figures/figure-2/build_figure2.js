#!/usr/bin/env node
// Current v53 researcher-artwork rebuild. Historical vector generator is in source/.
const cp=require('child_process'),path=require('path');cp.execFileSync(process.env.PYTHON||'python3',[path.join(__dirname,'rebuild_avatar.py'),...process.argv.slice(2)],{stdio:'inherit'});
