# Figure 2, revision 53

The human researcher now uses the original Figure 1 researcher-with-laptop illustration. The maintainer uses Figure 1’s reviewing researcher. The PNG bytes and original native crop rectangles are reused unchanged.

Current files: `MRFoundry-Figure-2-v53.pptx`, `MRFoundry-Figure-2-v53.pdf`, `MRFoundry-Figure-2-v53.png`. Existing agent artwork, scientific panels, labels, values, connectors and all non-human native objects are unchanged. The current manuscript caption is in `caption.md` and the paper figure manifest; speaker notes retain historical provenance with exact v54 corrections: Speaker notes only: fixed-snapshot terminology and accurate raster researcher provenance; no visual or scientific changes. Historical baseline notes remain unchanged.

## Portable rebuild

Install `requirements-avatar.txt` and Poppler, then run:

```sh
python3 rebuild_avatar.py --out rendered
```

Use `--pdftoppm /path/to/pdftoppm` if Poppler is not on PATH. All inputs are packaged under `source/` and `assets/`; no external workspace inputs or model runs are required. Existing legacy command names route to this rebuild.

`source/researcher-baseline.*` contains the frozen figure used by the current rebuild. Superseded avatar baselines are omitted from this package; earlier artifacts remain in publication history. Historical scripts are not the current renderer. The original Figure 1 contact sheet is `assets/researcher-original.png`; PowerPoint uses native crop rectangles, the PDF uses document clipping, and Figure 5’s SVG uses an equivalent viewport. No portrait is regenerated or raster-edited.

Publication PDFs retain the frozen scientific drawing streams. Figures 2–5 add localized human-role overlays; Figure 1 is copied exactly. Independent native PowerPoint exports are used for visual QA only. Preserving precise PDF page dimensions avoids rounding-induced changes to scientific rasterization.

`avatar-change-receipt.json` records scope, object IDs, hashes, native crop rectangles and exact overlay regions. Historical v53 PowerPoint inspection retained in native-review.json. Revision 54 changes exact speaker-note spans only; every visual ZIP member and publication PDF/PNG byte is identical. No new native-app inspection claimed. Fresh isolated rebuilds reproduce all PPTX member bytes, PDF bytes/text geometry and PNG pixels. Pixels outside human-role regions are identical to v52.

No simulation, reconstruction, grading, statistical calculation or agent comparison was rerun.
