#!/usr/bin/env python3
"""Current v53 researcher-artwork rebuild; historical generation source is in source/."""
from rebuild_avatar import main
if __name__=='__main__':main()
