#!/usr/bin/env python3
"""Current v52 original-agent rebuild; historical generation source is in source/."""
from rebuild_avatar import main
if __name__=='__main__':main()
