"""Repair only Figure 3's footer: researcher instruction and output have separate paths."""
from pathlib import Path
import copy, io, json, math, re, zipfile
from lxml import etree as E
from pypdf import PdfReader, PdfWriter
from pypdf.generic import DecodedStreamObject, NameObject, DictionaryObject, ArrayObject, FloatObject
from reportlab.pdfgen import canvas
from patch_avatars import PAT, shape_id, sha, pic, placements
from overlay_pdf import draw_crop

NS={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
EMU=914400
OLD_IDS=set(range(603,610))
NODE=(.04,4.075,1.26,.33)
FEEDBACK=[(1.30,4.24),(5.15,4.24),(5.15,4.00)]
OUTPUT=[(6.33,4.00),(6.33,4.125)]
COLOR='007C76'

def xml(s): return E.fromstring(s.encode())
def parse_shape(b):
    wrapper=('<p:spTree ' + ' '.join(f'xmlns:{k}="{v}"' for k,v in NS.items()) + '>').encode()
    return E.fromstring(wrapper+b+b'</p:spTree>')[0]
def move(s,x,y,w,h):
    q=s.find('.//a:xfrm',NS)
    q.attrib.clear()
    q.find('a:off',NS).attrib.update({'x':str(round(x*EMU)),'y':str(round(y*EMU))})
    q.find('a:ext',NS).attrib.update({'cx':str(round(w*EMU)),'cy':str(round(h*EMU))})
def rename(s,i,name):
    q=s.find('.//p:cNvPr',NS);q.set('id',str(i));q.set('name',name)
def text_copy(source,i,name,box,text,size=800,bold=True,color=COLOR):
    s=copy.deepcopy(source);rename(s,i,name);move(s,*box)
    s.find('.//a:t',NS).text=text
    q=s.find('.//a:rPr',NS);q.set('sz',str(size));q.set('b','1' if bold else '0')
    q.find('a:solidFill/a:srgbClr',NS).set('val',color)
    return s
def connector(i,name,points,start_id=None,end_id=None,arrow=True):
    (x0,y0),(x1,y1)=points
    x,y=min(x0,x1),min(y0,y1);w,h=abs(x1-x0),abs(y1-y0)
    flip=(' flipH="1"' if x1<x0 else '')+(' flipV="1"' if y1<y0 else '')
    connections=(f'<a:stCxn id="{start_id}" idx="3"/>' if start_id else '')+(f'<a:endCxn id="{end_id}" idx="0"/>' if end_id else '')
    tip='<a:tailEnd type="arrow" w="sm" len="sm"/>' if arrow else ''
    return xml(f'<p:cxnSp xmlns:p="{NS["p"]}" xmlns:a="{NS["a"]}"><p:nvCxnSpPr><p:cNvPr id="{i}" name="{name}"/><p:cNvCxnSpPr>{connections}</p:cNvCxnSpPr><p:nvPr/></p:nvCxnSpPr><p:spPr><a:xfrm{flip}><a:off x="{round(x*EMU)}" y="{round(y*EMU)}"/><a:ext cx="{round(w*EMU)}" cy="{round(h*EMU)}"/></a:xfrm><a:prstGeom prst="line"><a:avLst/></a:prstGeom><a:ln w="12065"><a:solidFill><a:srgbClr val="{COLOR}"/></a:solidFill>{tip}</a:ln><a:effectLst/></p:spPr></p:cxnSp>')
def footer_avatar():
    q=placements(3)[0];q.update(x=.085,y=4.10,w=.285)
    l,t,r,b=q['crop_ltrb_100000'];q['h']=q['w']*(100000-t-b)*1024/((100000-l-r)*1536)
    q['bounds_emu']=[round(q[k]*EMU) for k in ['x','y','w','h']];q['picture_shape_id']=613
    return q
def patch_ppt(path):
    path=Path(path)
    with zipfile.ZipFile(path) as z:
        infos=z.infolist();before={i.filename:z.read(i) for i in infos}
    key='ppt/slides/slide1.xml';objects={shape_id(m.group()):m.group() for m in PAT.finditer(before[key])}
    assert OLD_IDS<=objects.keys()
    frame=copy.deepcopy(parse_shape(objects[610]));rename(frame,612,'Researcher feedback source');move(frame,*NODE)
    label=text_copy(parse_shape(objects[609]),614,'Researcher source label',(.405,4.145,.825,.18),'Researcher',760,True)
    feedback_label=text_copy(parse_shape(objects[609]),609,'Feedback instruction',(1.40,4.075,3.55,.16),'Feedback: use KomaMRI',810,True)
    avatar=parse_shape(pic(footer_avatar()))
    added=[frame,avatar,label,feedback_label,connector(615,'Researcher feedback horizontal segment',FEEDBACK[:2],start_id=612,arrow=False),connector(617,'Researcher feedback into KomaMRI',FEEDBACK[1:]),connector(616,'Simulation outputs to saved artifacts',OUTPUT,end_id=610)]
    insertion=b''.join(E.tostring(s,encoding='utf-8') for s in added)
    replaced=PAT.sub(lambda m:b'' if shape_id(m.group()) in OLD_IDS else m.group(),before[key])
    replaced=replaced.replace(b'</p:spTree>',insertion+b'</p:spTree>')
    finalobjs={shape_id(m.group()):m.group() for m in PAT.finditer(replaced)}
    assert all(finalobjs[k]==v for k,v in objects.items() if k not in OLD_IDS)
    E.fromstring(replaced)
    out=path.with_suffix('.footer.tmp')
    with zipfile.ZipFile(out,'w') as z:
        for info in infos:z.writestr(info,replaced if info.filename==key else before[info.filename])
    out.replace(path)
    return {'changed_members':[key],'removed_ids':sorted(OLD_IDS),'new_ids':[612,613,614,615,616,617],'revised_label_id':609,'non_footer_shape_bytes_unchanged':True,'all_media_bytes_unchanged':True,'pptx_sha256':sha(path.read_bytes())}

def patch_pdf(path,asset):
    path=Path(path);r=PdfReader(path);p=r.pages[0];W,H=float(p.mediabox.width),float(p.mediabox.height);sx,sy=W/7.3,H/4.46
    buf=io.BytesIO();c=canvas.Canvas(buf,pagesize=(W,H),invariant=True)
    c.setFillColor('white');c.rect(0,0,W,H-4.012*sy,fill=1,stroke=0)
    c.setStrokeColorRGB(0,124/255,118/255);c.setLineWidth(.85)
    def rect(x,y,w,h):c.rect(x*sx,H-(y+h)*sy,w*sx,h*sy,fill=0,stroke=1)
    rect(*NODE);rect(5.43,4.125,1.8,.28)
    draw_crop(c,asset,footer_avatar(),W,H,sx,sy)
    def text(s,x,y,w,h,size,color=COLOR):
        c.setFillColor('#'+color);c.setFont('Helvetica-Bold',size)
        c.drawCentredString((x+w/2)*sx,H-(y+h/2)*sy-size*.34,s)
    text('Researcher',.405,4.145,.825,.18,7.6)
    text('Feedback: use KomaMRI',1.40,4.075,3.55,.16,8.1)
    text('Sequence + signals + checks',5.49,4.165,1.68,.18,8.0,'1B1B1B')
    def arrow(points):
        c.setStrokeColorRGB(0,124/255,118/255);c.setLineWidth(.95);c.setLineJoin(1)
        q=c.beginPath();q.moveTo(points[0][0]*sx,H-points[0][1]*sy)
        for x,y in points[1:]:q.lineTo(x*sx,H-y*sy)
        c.drawPath(q)
        (px,py),(x,y)=points[-2:];ang=math.atan2(y-py,x-px)
        for delta in (-.46,.46):c.line(x*sx,H-y*sy,(x-.045*math.cos(ang+delta))*sx,H-(y-.045*math.sin(ang+delta))*sy)
    arrow(FEEDBACK);arrow(OUTPUT);c.save()
    op=PdfReader(io.BytesIO(buf.getvalue())).pages[0];form=DecodedStreamObject();form.set_data(op.get_contents().get_data());form.update({NameObject('/Type'):NameObject('/XObject'),NameObject('/Subtype'):NameObject('/Form'),NameObject('/BBox'):ArrayObject([FloatObject(0),FloatObject(0),FloatObject(W),FloatObject(H)]),NameObject('/Resources'):op['/Resources']})
    resources=p['/Resources'];xo=resources.get('/XObject',DictionaryObject()).get_object();resources[NameObject('/XObject')]=xo;xo[NameObject('/MRFoundryFooterRepair')]=form
    stream=DecodedStreamObject();stream.set_data(b'q\n'+p.get_contents().get_data()+b'\nQ\nq\n/MRFoundryFooterRepair Do\nQ\n');p[NameObject('/Contents')]=stream
    w=PdfWriter();w.add_page(p);w.write(path)
    return {'pdf_sha256':sha(path.read_bytes()),'page_size_pt':[W,H],'changed_visual_region_in_top_left':[0,4.0,7.3,.46],'scientific_drawing_streams_retained':True,'feedback_path_in':FEEDBACK,'output_path_in':OUTPUT,'source_node_in':NODE}

def apply(ppt,pdf,asset,out):
    result={'amendment':'Figure 3 anchored feedback arrow','scientific_data_changed':False,'pptx':patch_ppt(ppt),'pdf':patch_pdf(pdf,asset)}
    Path(out).write_text(json.dumps(result,indent=2)+'\n');return result
