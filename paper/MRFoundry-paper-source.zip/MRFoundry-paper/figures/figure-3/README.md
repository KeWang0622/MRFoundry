# Figure 3, revision 51

The approved MRFoundry mascot replaces the agent icon. Researcher avatars, all scientific drawings, images, values, labels, and layout are retained. The original outlined wordmark is unchanged.

Current files: `MRFoundry-Figure-3-v51.pptx`, `MRFoundry-Figure-3-v51.pdf`, `MRFoundry-Figure-3-v51.png`. The PPTX keeps all non-avatar objects editable and unchanged. The generated mascot is intentionally an embedded raster asset.

## Portable rebuild

Install `requirements-avatar.txt` and Poppler, then run:

```sh
python3 rebuild_avatar.py --out rendered
```

Use `--pdftoppm /path/to/pdftoppm` if Poppler is not on PATH. All source inputs are packaged under `source/` and `assets/`; no old workspace path or model run is required. Current legacy command names route to this same rebuild. `source/legacy-*` and `source/historical-*` are historical evidence, not the active renderer. The baseline PPTX notes retain their original provenance; the current manuscript caption is in the paper's figure manifest.

The publication PDF retains the original PDF drawing stream and scientific image streams, with localized opaque avatar masks and the actual approved mascot. This preserves saved scientific rendering. It is **not** a fresh PowerPoint PDF export. Each new PPTX was also opened, inspected, and separately exported locally in PowerPoint for QA. `avatar-change-receipt.json` records native and publication methods separately, exact hashes, and comparison results.

No simulation, reconstruction, grading, or agent comparison was rerun.
