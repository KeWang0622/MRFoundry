# Figure 3: sequence construction and checks

Current files: `MRFoundry-Figure-3-v53.pptx`, `MRFoundry-Figure-3-v53.pdf` and `MRFoundry-Figure-3-v53.png`. The suffix retains the editable source lineage. The current amendment connects a framed Researcher source to the KomaMRI panel and draws the outgoing results connection separately. The researcher portrait and native crop come from Figure 1. Scientific panels, their labels and numerical values are unchanged.

## Portable rebuild

Install `requirements-avatar.txt` and Poppler, then run:

```sh
python3 rebuild_avatar.py --out rendered
```

Use `--pdftoppm /path/to/pdftoppm` if Poppler is not on PATH. All inputs are packaged under `source/` and `assets/`; existing legacy command names route to this rebuild. It does not run MRI code or agent comparisons.

`rebuild_avatar.py` applies the Figure 1 researcher artwork, preserves the reviewed speaker-note corrections and calls `patch_footer.py` for the current connector amendment. The PowerPoint uses editable frames, standard line segments and arrowheads. The publication PDF preserves the frozen scientific drawing streams and adds a footer-local overlay; the PNG is rendered from that PDF. The caption is retained in `caption.md` and the paper figure manifest.

`footer-arrow-receipt.json` and `avatar-change-receipt.json` record the current change. The package's `figure3-arrow-amendment.json` and `provenance/` bind the exact source, export and review hashes. Current visual QA used a LibreOffice Impress export of the native PPTX, along with the publication PDF and PNG. Microsoft PowerPoint inspection was unavailable; `native-review.json` is a historical review of the earlier artifact, not approval of this amendment.

The original Figure 1 portrait asset and scientific inputs remain unchanged. Earlier avatar and speaker-note checks remain historical provenance. No simulation, reconstruction, grading, statistical calculation or agent comparison was rerun.
