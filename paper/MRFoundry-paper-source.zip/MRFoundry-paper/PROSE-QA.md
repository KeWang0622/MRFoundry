# Editorial scope and claim checks

- Toolbox first: explain the opportunity, MRI-specific decisions, skill organization and supervised workflows before the bounded evaluation.
- MRI Agent Bench has dedicated Methods and Results subsections, with public task details linked to its separate repository.
- No MRFoundry version suffix in the abstract or narrative. Exact evaluation provenance remains fixed and traceable.
- The abstract retains the distinction between the stronger Core result and the less conclusive Hard evidence, without confidence intervals or P values.
- Neither demonstrations nor memory records are described as controlled evidence of RSI benefit. Sequence skill retrieval is explicitly scoped to a later audit.
- Methods and results keep the two Hard cohorts distinct, report exclusions and setup incidents, and retain uncertainty and unfavorable outcomes.
- h5py supports HDF5 reading; the M4Raw release contract supports axis/support interpretation. The citations are attached to their respective clauses.
- Library/method references establish method descriptions, while saved local evidence establishes the reported execution and numerical outcomes.
- Numerical source files, Table 1 and Table 2 result cells are checked against revision 50. Main prose, captions and SI reporting were revised without recomputing outcomes. Exact SI changes are listed in preservation-exceptions.json. The prior agent artwork is restored; the scanner mascot is used only for Figure 1 branding. Table 2 uses the shorter label “With MRFoundry”; all result cells and cohort definitions are preserved.

Detailed reference checks and access limitations are recorded separately. The audit does not assert access to every publisher's full text or substitute for author approval of the manuscript.
