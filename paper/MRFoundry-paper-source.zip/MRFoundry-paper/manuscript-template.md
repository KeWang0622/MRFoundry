# MRFoundry: Knowledge-Guided Agent Loops for End-to-End MRI Research

LOCAL MANUSCRIPT — 3 November 2026, revision 51. Not submitted. Author and publication decisions are listed in AUTHOR_CONFIRMATIONS.md. Earlier drafts and evidence remain preserved.

## Abstract

Recent advances in AI agents have expanded their ability to write code, use software, and revise computational workflows, creating an opportunity to assist MRI research. Applying these capabilities requires connecting acquisition physics, data conventions, specialized tools, and scientific validation. We present MRFoundry, an open-source toolbox that makes this knowledge available to existing agents through seven complementary skills. The skills connect scientific references and established tools to concrete actions and output checks, while project-local memory preserves decisions and evidence for reuse. We demonstrate guidance use in a later audit of a researcher-supervised sequence prototype and during acquired-data reconstruction, showing how an agent combines tools and inspects outputs. We also present MRI Agent Bench as an accompanying evaluation resource and use paired offline comparisons to assess MRFoundry across models and MRI task domains. MRFoundry improved aggregate verified completion on the Core benchmark; evidence on harder tasks was less conclusive. MRFoundry provides a practical foundation for connecting MRI knowledge, computational tools, and researcher supervision in agent-assisted research.

## 1 Introduction

AI agents can write code, operate software and use execution feedback to carry out computational work [@react;claudeloop;sweagent;datainterpreter], including scientific workflows [@coscientist]. Applying these capabilities across MRI research requires connecting acquisition physics, hardware constraints, data conventions and computational assumptions [@bernstein]. An executable reconstruction may use incorrect axes or sampling conventions; a valid sequence file still requires physical and numerical checks.

Selecting software is therefore only one decision in a research workflow. The agent must establish what inputs represent, how tools can be combined and which checks support interpretation. Guidance connecting these decisions can help researchers use the existing MRI ecosystem across acquisition, simulation, reconstruction, analysis and reporting.

MRFoundry is an open-source toolbox that organizes MRI knowledge into seven complementary skills for existing agents [@mrfoundry]. The skills connect scientific references, software instructions and output checks. Project-local memory retains evidence behind decisions, and selected lessons can improve shared guidance through human review. Agent4MR couples sequence generation to physics-aware validation, while BCER supplies a controller for long MRI workflows with explicit artifact binding [@agent4mr;bcer]. MRFoundry supplies reusable guidance across MRI domains; execution and recovery remain the host's responsibility.

We illustrate researcher-supervised sequence construction with a later skill-guided audit, and reconstruction with guidance consulted during the run. We also introduce MRI Agent Bench as an accompanying evaluation resource and compare matched agents with and without MRFoundry. Benchmark specifications and public tasks are maintained separately [@blochbenchtasks;blochbench].

## 2 Methods

### 2.1 Knowledge-guided research workflows

Figure 1 shows the intended loop: the researcher supplies a question, inputs and constraints; the agent consults skills, plans actions, executes tools and checks outputs. Failed checks can prompt revision. MRFoundry describes these steps; the host and researcher control their execution.

#### 2.1.1 Skill organization and MRI knowledge

Each skill contains instructions, references and, where useful, helper scripts. Its entry point identifies when it applies and links to focused concepts, software setup and evaluation material.

Table 1 groups seven skills into two general and five specialist skills. The general MRI navigator connects concepts, formats, software and references; the research-workflow skill connects study design, experiments, evaluation and writing [@mrfoundry]. Specialists cover hardware, pulse-sequence design, conventional reconstruction, deep-learning reconstruction and diffusion MRI. Skills can be combined across domains, for example when sequence design requires hardware and reconstruction guidance. The reference index connects instructions to annotated papers, textbooks, courses and software documentation [@mrfoundryindex].

#### 2.1.2 Agent workflow and tool use

Hosts such as Claude Code and Codex expose the skills; established applications perform computations [@claudecode;codex]. The command `npx skills add KeWang0622/MRFoundry` installs the guidance; `--skill mri-reconstruction` selects one skill [@skillscli;mrfoundry]. Applications and restricted datasets retain their installation, access and license requirements.

Guidance asks agents to inspect inputs and environments, resolve missing information, install dependencies in isolation, and check a small upstream example [@toolsetup]. Connections between applications must preserve units, axes, sample order and model assumptions. Output checks address the research request, beyond successful execution.

### 2.2 Research memory and shared guidance

Figure 2 distinguishes reusable public skills from project notebooks in `.mrfoundry/`, which retain requests, inputs, versions, parameters, commands, outputs and unsuccessful attempts [@memoryguide]. A reusable lesson must state its evidence and scope. Before later work, the agent retrieves relevant lessons and rechecks them against new data and environments; it can retain, revise or reject them without erasing provenance. User preferences remain separate from scientific findings.

This proposed recursive self-improvement cycle updates written guidance, not model weights. The initializer can add retrieval instructions to `AGENTS.md` or `CLAUDE.md`; the host controls loading and execution [@memoryguide]. Its effect on subsequent tasks was not evaluated.

### 2.3 Local adaptation and public contribution

Researchers can retain lessons locally, adapt guidance to group conventions, or propose shared changes. Notebooks are excluded from Git by default. Public contributions remove private context and supply a scientific source or tested example [@memoryguide;contributing]. Contributors edit a skill or reference on a branch and open a pull request (PR). Repository checks validate structure and links; a maintainer reviews the instruction before merging [@contributing]. This contribution mechanism was not evaluated for performance gains.

### 2.4 Demonstration design

Two researcher-supervised Codex examples connect decisions to scientific checks (Figures 3–4). Saved scripts, reports and project records document actions and revisions. Sequence skill retrieval occurred during a later audit, not original construction; reconstruction guidance reads occurred during the run. Neither example had a matched unguided baseline. Supporting Information retains numerical details, provenance, implementation history and a separate diffusion example. NumPy, SciPy and Matplotlib supported computation and display [@numpy;scipy;matplotlib].

#### 2.4.1 Designing and checking a sequence

The task was to design, export and inspect a golden-angle radial gradient-echo (GRE) prototype. PyPulseq 1.5.0.post1 produced a Pulseq file with TE/TR 5/15 ms, 128 spokes of 64 samples and 111.246-degree rotation [@pypulseq;pulseq;winkelmann]. Figure 3 and Supporting Information give acquisition settings and configured gradient limits.

The agent checked timing and gradients and compared exported and prewrite trajectories. At the researcher's request, it replaced an initial custom simulator with KomaMRI, inspected the installed API, ran its official EPI example, and simulated the GRE on a 13,497-spin brain phantom [@koma]. Halving the RF integration step tested temporal discretization. An adapter preserved coordinates and phase when passing samples and trajectory to SigPy [@sigpy].

#### 2.4.2 Comparing reconstructions

The task was to reconstruct an acquired four-channel, 0.3-T T2-weighted M4Raw brain slice at two retrospective sampling settings [@m4raw;m4rawdata]. The agent consulted guidance, inspected the HDF5 array with h5py [@h5py], and used the release contract to resolve axes and acquired support [@m4format]. It first ran SENSE and inspected discrepancies and residuals [@sense]. After checking calibration, it retained the ESPIRiT maps and tried L1-wavelet reconstruction with weight 0.01 at both masks [@sigpy;sigpydocs;espirit;sparsemri;pywavelets].

The comparison preserved initial SENSE outputs and held sensitivity maps and reconstruction settings fixed between masks. Magnitude discrepancies used the noisy all-source root-sum-of-squares (RSS) image as reference. Sampled/withheld-line residuals and additional iterations separated numerical stability from agreement with measured data.

### 2.5 MRI Agent Bench and comparison

[MRI Agent Bench](https://github.com/KeWang0622/MRIAgentBench) provides executable research tasks with specified inputs, artifacts and automated checks (Figure 5). Public Core contains 24 task types across ten MRI domains and 88 data variants [@blochbenchtasks;blochbench]. A type specifies a problem structure; an instance fixes data and parameters.

Each pair ran concurrently through Codex in separate sandboxes with the same model, nominal reasoning setting, tools, inputs and time limit [@codex]. Search was disabled; network access was limited to package indexes. The intervention comprised seven frozen skills plus their project-level discovery instruction; the agent chose whether to read them. The snapshot was fixed before evaluated Core instances were opened; subsequently authored Hard tasks were not used to revise it [@mrfoundry014].

Ten models each attempted one sealed instance per Core type (240 pairs), rather than all 88 variants. For Hard, three models attempted two instances of all 15 types (90 pairs); four further models attempted one instance of 11 multi-stage types (44 pairs; Table 2). Four Hard types required broader system designs. Verified completion required every frozen check to pass. A two-way task-type/model cluster bootstrap supplied 95% percentile intervals (4,000 resamples, seed 0), interpreted as sensitivity to the selected panel. Supporting Information gives the original algorithm, secondary unclustered McNemar comparisons, task validation, grading and budgets.

All model-reaching trials for the ten analyzed models were retained. Nine started pairs for an eleventh model were excluded after its API rejected the host's editing tool. We restarted 143 pair setups (94 Core, 49 Hard) that failed before either model turn, keeping task/model conditions unchanged. Memory and disk policies changed during evaluation. Documented memory limits were matched within newly prepared pairs, but records do not establish uniform resources throughout the study. Supporting Information documents policy changes, missing exposure records and a retained Hard image-subcheck weakness.

## 3 Results

### 3.1 Research demonstrations

#### 3.1.1 Sequence and simulation checks

Figure 3 shows construction, simulation and inspection. Readback found no timing errors; maximum per-axis gradient and slew (12.735 mT/m and 125.266 T/m/s) met configured limits. The 128 spokes contained 8,192 ADC samples. Exported/prewrite coordinates differed by at most 0.00162 cycles/m, and halving the RF step changed the complex signal by 0.07096%. These checks support timing, trajectory transfer and one discretization choice, not scanner readiness or diagnostic quality.

#### 3.1.2 Sampling and reconstruction comparison

Source inspection found 195 acquired phase-encoding lines in the 256-column grid. Masks retained 110 and 67 acquired lines, giving effective accelerations of 1.77 and 2.91 (Figure 4). Outputs included complex reconstructions, masks, sensitivity maps and source-linked summaries.

At both settings, zero-filled RSS was closer to noisy all-source RSS than L1-wavelet reconstruction. Substantial sampled- and withheld-line residuals persisted despite small changes with additional iterations. Supporting Information retains complete diagnostics; the noisy reference does not establish image accuracy.

All-source RSS matched the provider's reference with relative L2 error 8.85 × 10^-8. This verifies the source-image construction, not the accuracy of the undersampled reconstruction.

### 3.2 A retained research lesson

The acquired-support record links the 195-line denominator to its source digest, release contract and numerical report (Figure 2). Its lesson is to verify axes and acquired support before masking or calculating acceleration; 195 is source-specific. This demonstrates evidence-linked documentation, not improved performance on a later task.

### 3.3 MRI Agent Bench comparison

MRFoundry achieved 188 versus 162 completions across 240 Core pairs (78.3% versus 67.5%; difference 10.8 percentage points, 95% CI 0.8 to 21.2). Discordant pairs comprised 39 with-only and 13 without-only completions (Figure 5).

Hard completion rose from 49 to 60/134 (36.6% to 44.8%; difference 8.2 points, 95% CI −3.9 to 19.7), with 20 with-only and nine without-only completions. Its interval includes zero. Table 2 separates Hard cohorts because coverage differs. Supporting Information retains Core domain/model results, Hard cohorts and token-use measures.

## 4 Discussion

MRFoundry connects MRI knowledge and software through instructions for planning, tool use and output checks. Core results support usefulness under the tested conditions; Hard evidence was less conclusive. Gains varied across tasks, and the package-level comparison does not isolate individual instructions.

The demonstrations show why checks matter: sequence export requires timing and coordinate verification, while reconstruction requires explicit sampling conventions and reference definitions. The sequence required researcher intervention; reconstruction did not improve agreement over zero-filled RSS. Established applications provide numerical methods, and guidance helps select and inspect their use.

Project memory records the evidence behind decisions. Self-Refine studies revision through textual feedback, and Reflexion retains feedback across attempts [@selfrefine;reflexion]. Whether MRFoundry's records improve later work requires longitudinal comparison; memory reuse and community contributions were not isolated here.

Tasks were agent-authored within an author-selected scope; Core shares problem structure with development tasks, and independent expert review is incomplete. One run per Core task–model combination does not establish repeated-run reliability. Hard coverage differs, and nominal reasoning settings do not equalize provider budgets. Automated checks measure specified outputs, not researcher effort, judgment or clinical validity. Historical model snapshots, full execution configurations and per-run resource exposure are unavailable. Setup incidents, shared resources and the retained grading weakness further limit interpretation. Demonstrations lack matched baselines and establish neither scanner safety nor diagnostic benefit.

## 5 Conclusion

MRFoundry connects MRI knowledge, established software and researcher supervision through reusable skills. The demonstrations document a later skill-guided sequence audit and guidance use during reconstruction. The paired Core comparison supports domain guidance under tested conditions; benefits from memory reuse and shared contributions remain unmeasured.

## Data and software availability

MRFoundry source and contribution guidance are available at https://github.com/KeWang0622/MRFoundry [@mrfoundry;contributing], with the evaluated snapshot preserved separately [@mrfoundry014]. The reference index and tutorial provide entry points [@mrfoundryindex;mrfoundrytutorial]. MRI Agent Bench publishes Core tasks, data, checkers and result exports [@blochbenchtasks;blochbench]. Hard materials, per-task outcomes and traces remain private; only aggregates are reported. The [paper evidence directory](https://github.com/KeWang0622/MRFoundry/tree/main/paper/evidence) supplies original demonstration scripts, reports, input identities, recorded environments and historical evaluation settings, with gaps and reproduction limits stated explicitly. Raw data remain in their original releases; M4Raw Brain v1.6 is CC BY 4.0 [@m4rawdata].

## AI assistance disclosure

AI tools supported software development, writing and explanatory illustrations under the author's direction. Scientific MRI images and quantitative plots derive from recorded data and numerical outputs without generative enhancement. The author is responsible for the scientific content and final manuscript.
