# MRFoundry: Knowledge-Guided Agent Loops for End-to-End MRI Research

LOCAL MANUSCRIPT — 3 November 2026, revision 52. Not submitted. Author and publication decisions are listed in AUTHOR_CONFIRMATIONS.md. Earlier drafts and evidence remain preserved.

## Abstract

Recent advances in AI agents have expanded their ability to write code, use software, and revise computational workflows, creating an opportunity to assist MRI research. Applying these capabilities requires connecting acquisition physics, data conventions, specialized tools, and scientific validation. We present MRFoundry, an open-source toolbox that makes this knowledge available to existing agents through seven complementary skills. The skills connect scientific references and established tools to concrete actions and output checks, while project-local memory preserves decisions and evidence for reuse. Researchers can adapt guidance locally and propose generalizable improvements through reviewed contributions. We demonstrate guidance use in a later audit of a researcher-supervised sequence prototype and during acquired-data reconstruction, showing how an agent combines tools, inspects outputs, and records unresolved questions. Alongside MRFoundry, we introduce MRI Agent Bench as an accompanying evaluation resource and use paired offline comparisons across models and MRI task domains. MRFoundry improved aggregate verified completion on the Core benchmark; evidence on harder tasks was less conclusive. MRFoundry provides a practical foundation for connecting MRI knowledge, computational tools, and researcher supervision in agent-assisted research.

## 1 Introduction

AI agents can write code, operate software, and use execution feedback to carry out computational work [@react;claudeloop;sweagent;datainterpreter]. Their application to scientific workflows creates an opportunity to help researchers connect specialized tools, inspect intermediate results, and revise an implementation as a question develops [@coscientist]. For MRI, useful assistance must extend across acquisition design, simulation, reconstruction, analysis, and reporting. These stages depend on different software environments but share assumptions about the underlying experiment.

MRI decisions connect acquisition physics, hardware constraints, data conventions, and computational models [@bernstein]. A reconstruction can execute successfully while using incorrect axes or sampling conventions. A valid sequence file can still require physical and numerical checks. The practical difficulty is therefore not simply finding a software package: the agent must establish what the inputs represent, preserve their meaning between applications, and choose evidence that supports interpretation. Much of this knowledge is distributed across publications, documentation, and laboratory experience.

The opportunity is to make that knowledge actionable at the point of a decision. A researcher asking for a sequence prototype needs more than generated code: the workflow must connect requested timing to an exported sequence and then to a simulation that reads it correctly. Similarly, a reconstruction request requires a clear relationship between measured k-space, a sampling mask, an encoding model, and a comparison image. These connections motivate guidance organized around research tasks.

MRFoundry organizes this knowledge into seven complementary skills for existing agents [@mrfoundry]. Each skill connects scientific references and software instructions to actions and output checks. A project-local notebook preserves the evidence behind decisions, and selected lessons can improve shared guidance through human review. The researcher supplies the question and constraints; the agent consults guidance and performs the computational work; established applications provide the numerical methods. Agent4MR couples sequence generation to physics-aware validation, while BCER supplies a controller for long MRI workflows with explicit artifact binding [@agent4mr;bcer]. MRFoundry supplies reusable guidance across MRI domains, with execution and recovery remaining the host's responsibility.

We describe the toolbox and its contribution workflow, then illustrate researcher-supervised sequence construction with a later skill-guided audit and acquired-data reconstruction with guidance consulted during the run. Alongside MRFoundry, we introduce MRI Agent Bench and compare matched agents with and without the toolbox. Benchmark specifications and public tasks are maintained separately [@blochbenchtasks;blochbench]. The comparison tests the frozen guidance package; it does not isolate individual skills or measure benefits from later memory reuse.

## 2 Methods

### 2.1 Knowledge-guided research workflows

Figure 1 shows the intended loop. The researcher supplies a question, inputs, and constraints. The agent identifies relevant skills, plans actions, executes tools, and checks whether the outputs address the question. Failed checks can prompt revision of an implementation or its assumptions. MRFoundry describes this process in instructions; the host and researcher control execution and decide when further work is needed.

#### 2.1.1 Skill organization and MRI knowledge

Each skill has an entry point that identifies when it applies and links to focused instructions, references, and, where useful, helper scripts. Short instructions guide the next decision, while linked material supplies the underlying concepts or software details. This organization lets the agent consult relevant topics without loading every reference for every request. A skill is a readable instruction package that the host agent interprets in context. It is not a separate model or a callable reconstruction algorithm. The same entry point can therefore guide tasks with different data and constraints, while the specific commands and checks follow from the current request.

Table 1 groups the seven skills into two general and five specialist skills. The MRI navigator connects concepts, formats, software, and references across the field. The research-workflow skill connects study design, experiments, evaluation, and writing [@mrfoundry]. Specialist skills cover hardware, pulse-sequence design, conventional reconstruction, deep-learning reconstruction, and diffusion MRI. They address decisions such as choosing an encoding model, checking gradient conventions, or establishing reconstruction baselines. Skills can be combined when a task crosses domains: sequence design may require hardware limits and reconstruction conventions, while a learned reconstruction study requires conventional comparisons and a defensible evaluation design.

The reference index connects these instructions to annotated papers, textbooks, courses, and software documentation [@mrfoundryindex]. References explain why a method is appropriate; software instructions explain how to use a particular implementation. The listed coverage describes the toolbox's scope rather than demonstrated competence in every topic. For example, a reconstruction task can begin with the specialist skill, follow a format reference to establish array conventions, and consult workflow guidance to define a baseline and endpoint. This use of linked references makes the relationship between an instruction and its scientific basis visible to both the agent and researcher.

#### 2.1.2 Agent workflow and tool use

Hosts such as Claude Code and Codex expose the skills to the agent [@claudecode;codex]. The command `npx skills add KeWang0622/MRFoundry` installs the guidance; `--skill mri-reconstruction` selects one skill [@skillscli;mrfoundry]. Scientific applications and restricted datasets retain their installation, access, and license requirements. MRFoundry does not replace those applications or implement their numerical solvers.

Before execution, guidance asks the agent to inspect the input data and working environment, resolve missing information, install dependencies in isolation, and check a small upstream example [@toolsetup]. When connecting applications, the agent must preserve units, axes, sample order, and model assumptions. For example, reconstruction requires distinguishing the stored grid from acquired support before constructing a mask. After execution, the agent inspects artifacts and quantitative checks against the research request. A successful command is one intermediate observation; a usable result also needs a documented input interpretation, comparison reference, and explanation of remaining uncertainty.

### 2.2 Research memory and shared guidance

Figure 2 distinguishes reusable public skills from project-local evidence. The `.mrfoundry/` notebook contains an index, working preferences, environment information, evidence-linked lessons, and individual run records [@memoryguide]. Run records retain requests, input identifiers, versions, parameters, commands, outputs, and unsuccessful attempts. Keeping these details with the project allows another session to recover the reasoning behind a decision rather than only its final code.

A reusable lesson states the observation, supporting evidence, scope, and conditions for revalidation. Before later work, the agent reads the index, retrieves relevant lessons, and checks whether they apply to the current data and environment. It may retain, narrow, or reject a lesson. Conflicting evidence supersedes the earlier interpretation without erasing the original run. User preferences, such as a preferred reporting format, remain separate from scientific findings. This distinction prevents a local working habit from becoming an unsupported methodological rule.

This proposed recursive self-improvement cycle updates written guidance, not model weights. The initializer can add retrieval instructions to project `AGENTS.md` or `CLAUDE.md` files; the host controls their loading and execution [@memoryguide]. Recording a retrospective is only the first step: improvement would require applying a lesson in subsequent work and checking the resulting outcome. We demonstrate evidence-linked recording, but did not evaluate later retrieval or its effect on task performance. The distinction matters because a recorded command can depend on a software version or source dataset. Reusing its conclusion without checking those conditions could repeat an error. The notebook therefore carries both reusable guidance and the information needed to decide when it should no longer be applied.

### 2.3 Local adaptation and public contribution

Researchers can retain a lesson locally, adapt guidance to group conventions, or propose a generalizable change to the public toolbox. Project notebooks are excluded from Git by default. A public contribution selects the relevant instruction, removes private context, and supplies a scientific source or tested example [@memoryguide;contributing]. The notebook itself is not automatically published.

Contributors edit the appropriate skill or reference on a branch and open a pull request (PR). Repository checks validate structure and links, while a maintainer reviews the content before merging [@contributing]. A group can review the resulting update before adopting it. This separates an observation from one project from an instruction intended for broader use and gives corrections a traceable source. For instance, a source-specific array observation can motivate a general instruction to verify the release format, while its particular dimensions remain in the local record. Automated checks validate repository structure and look for broken links; scientific relevance and the scope of a proposed rule still require review. The contribution mechanism is implemented, but its effect on scientific quality or performance was not evaluated.

### 2.4 Demonstration design

Two researcher-supervised Codex examples connect agent actions to scientific checks (Figures 3–4). Saved scripts, reports, and project records document tool use and revisions. Sequence skill retrieval occurred during a later audit, not original construction; reconstruction guidance reads occurred during the run. Neither example had a matched unguided baseline. Supporting Information retains numerical details, provenance, implementation history, and a separate diffusion example. NumPy, SciPy, and Matplotlib supported computation and display [@numpy;scipy;matplotlib].

#### 2.4.1 Designing and checking a sequence

The task was to design, export, and inspect a golden-angle radial gradient-echo (GRE) prototype. PyPulseq 1.5.0.post1 produced a Pulseq file with a 220-mm field of view, 5-mm slice, 10-degree nominal flip, TE/TR 5/15 ms, and 128 spokes of 64 samples [@pypulseq;pulseq]. Successive spokes rotated by 111.246 degrees [@winkelmann]. Configured per-axis gradient and slew limits were 32 mT/m and 130 T/m/s.

The agent constructed RF, gradient, and ADC events, checked timing and gradients, and compared trajectories before and after export. At the researcher's request, it replaced an initial custom simulator with KomaMRI, inspected the installed API, and ran the official EPI example before simulating the exported GRE on a 13,497-spin brain phantom [@koma]. Halving the RF integration step tested temporal discretization on the same phantom. An adapter preserved coordinates and phase when passing samples and trajectory to SigPy [@sigpy]. These steps examined the connections between sequence construction, exported representation, and simulated signal rather than relying on one final image. Reopening the exported file checked what another application would receive. Running an upstream simulator example checked the installed environment before introducing the study sequence. The RF-step comparison then examined whether one simulation setting materially changed the retained signal. Each check addressed a different possible source of implementation error.

#### 2.4.2 Comparing reconstructions

The task was to reconstruct an acquired four-channel, 0.3-T T2-weighted M4Raw brain slice at two retrospective sampling settings [@m4raw;m4rawdata]. The agent consulted guidance, inspected the HDF5 array with h5py [@h5py], and used the release contract to resolve axes and acquired support [@m4format]. It first ran SENSE and inspected image discrepancies and measurement residuals [@sense]. After checking calibration, it retained the ESPIRiT maps and tried L1-wavelet reconstruction with weight 0.01 at both masks [@sigpy;sigpydocs;espirit;sparsemri;pywavelets].

The comparison preserved initial SENSE outputs and held sensitivity maps and reconstruction settings fixed between masks. Magnitude discrepancies used the noisy all-source root-sum-of-squares (RSS) image as reference. Sampled-line residuals assessed agreement with measurements used in the solve; withheld-line residuals used acquired measurements omitted from it. Additional iterations assessed numerical stability. These distinct checks made it possible to separate a stable optimization output from one that agreed with measured data. The same source-derived normalization and display window were used for the image comparison.

### 2.5 MRI Agent Bench and comparison

[MRI Agent Bench](https://github.com/KeWang0622/MRIAgentBench) provides executable research tasks with specified inputs, artifacts, and automated checks (Figure 5). Public Core contains 24 task types across ten MRI domains and 88 data variants [@blochbenchtasks;blochbench]. Coverage includes sequence design, reconstruction, quantitative imaging, analysis, and research planning and reporting. A type specifies a problem structure; an instance fixes data and parameters. The accompanying repository describes tasks and submission artifacts in detail. Separate author agents without access to the skills wrote specifications and private graders and generated data, parameters, and wording. Reference solutions and positive and negative controls were used to check instances before hashing and sealing them. This process checked the intended automated behavior; independent external MRI-expert review remains incomplete.

Each pair ran concurrently through Codex in separate sandboxes with the same model, nominal reasoning setting, tools, inputs, and time limit [@codex]. Search was disabled; network access was limited to package indexes. The intervention comprised seven frozen skills plus their project-level discovery instruction; the agent chose whether to read them. The snapshot was fixed before evaluated Core instances were opened; subsequently authored Hard tasks were not used to revise it [@mrfoundry014].

Ten models each attempted one sealed instance per Core type, giving 240 pairs rather than evaluating all 88 variants. For Hard, three models attempted two instances of all 15 types (90 pairs); four further models attempted one instance of 11 multi-stage types (44 pairs; Table 2). Four Hard types required broader system designs. Verified completion required every frozen automated check to pass. Checks examined submitted artifacts independently of the agent's report, including exported sequences, numerical outputs, code, and claims against supplied results. No language-model judge supplied completion labels.

The primary effect was the difference in paired completion proportions. A two-way task-type/model cluster bootstrap supplied 95% percentile intervals (4,000 resamples, seed 0), interpreted as sensitivity to the selected panel. Supporting Information gives the original algorithm, secondary unclustered McNemar comparisons, task validation, grading, and budgets.

All model-reaching trials for the ten analyzed models were retained. Nine started pairs for an eleventh model were excluded after its API rejected the host's editing tool. We restarted 143 pair setups (94 Core, 49 Hard) that failed before either model turn, keeping task/model conditions unchanged. Memory and disk policies changed during evaluation. Documented memory limits were matched within newly prepared pairs, but records do not establish uniform resources throughout the study. Supporting Information documents policy changes, missing exposure records, and a retained Hard image-subcheck weakness.

## 3 Results

### 3.1 Research demonstrations

#### 3.1.1 Sequence and simulation checks

Figure 3 follows the research request through sequence construction, simulation, and inspection. Readback found no timing errors; maximum per-axis gradient and slew were 12.735 mT/m and 125.266 T/m/s, within configured limits. The 128 spokes contained 8,192 ADC samples. Exported/prewrite coordinates differed by at most 0.00162 cycles/m, and halving the RF step changed the complex signal by 0.07096%.

The resulting Pulseq file, trajectory, and simulation records made these checks inspectable at each connection between tools. They support timing, trajectory transfer, and one temporal-discretization choice. They do not establish full physical-model convergence, scanner readiness, or diagnostic image quality. The researcher's intervention in simulator selection remains part of the demonstrated workflow.

#### 3.1.2 Sampling and reconstruction comparison

Source inspection found 195 acquired phase-encoding lines in the 256-column grid. Masks retained 110 and 67 acquired lines, giving effective accelerations of 1.77 and 2.91 (Figure 4). Outputs included complex reconstructions, masks, sensitivity maps, and source-linked summaries. All-source RSS matched the provider's reference with relative L2 error 8.85 × 10^-8, verifying source-image construction rather than undersampled reconstruction accuracy.

L1-wavelet reconstruction reduced magnitude discrepancy relative to the initial SENSE outputs, but zero-filled RSS remained closer to noisy all-source RSS at both settings. Substantial sampled- and withheld-line residuals persisted despite small changes with additional iterations. The saved comparison therefore documents an inspected revision with unresolved data agreement. Supporting Information retains complete diagnostics; the noisy reference does not establish image accuracy.

### 3.2 A retained research lesson

The acquired-support record links the 195-line denominator to its source digest, release contract, and numerical report (Figure 2). Its lesson is to verify axes and acquired support before masking or calculating acceleration; 195 is source-specific. The initial calculation already used this denominator, so the record is not evidence of correcting an executed 256-based estimate. It demonstrates how a concrete decision can be retained with its scope and evidence for later revalidation, not improved performance on a subsequent task.

### 3.3 MRI Agent Bench comparison

MRFoundry achieved 188 versus 162 completions across 240 Core pairs (78.3% versus 67.5%; difference 10.8 percentage points, 95% CI 0.8 to 21.2). Discordant pairs comprised 39 with-only and 13 without-only completions (Figure 5). These counts show that the aggregate gain includes both improvements and regressions on individual pairs.

Hard completion rose from 49 to 60/134 (36.6% to 44.8%; difference 8.2 points, 95% CI −3.9 to 19.7), with 20 with-only and nine without-only completions. Its interval includes zero. Table 2 separates Hard cohorts because coverage differs. Supporting Information retains Core domain/model results, Hard cohorts, and token-use measures. The findings concern availability of the complete guidance package under the recorded execution conditions. Seven models improved in aggregate Core count and three were unchanged, although unchanged totals could contain different successful pairs. The model-level table makes that coverage explicit; the aggregate result is not a general model ranking.

## 4 Discussion

### 4.1 Connecting MRI knowledge to agent actions

MRFoundry makes MRI expertise available in a form an existing agent can consult while working. Its practical contribution is the connection between a research question, relevant scientific sources, tool-specific actions, and output checks. Researchers can use a general skill to frame a task and combine specialist guidance as the work crosses domains. This supports incremental adoption within an existing software environment rather than requiring a new numerical stack. The plain-text organization also exposes instructions for inspection and revision: a researcher can follow a reference, examine a recommended check, or contribute a correction. This transparency is useful when a workflow depends on conventions that are easy to leave implicit, such as acquired support or the meaning of a reference image.

The Core comparison supports the usefulness of making this guidance available under the tested conditions. Hard evidence was less conclusive, and gains varied across tasks. Because the intervention bundled all seven skills and their discovery instruction, it cannot identify which components caused a change. The results motivate further study of guidance selection and use; they do not establish that more instruction always improves an agent.

### 4.2 Evidence, supervision, and reusable lessons

The demonstrations show why intermediate checks matter. Sequence export requires timing and coordinate verification before simulated behavior can be interpreted. Reconstruction requires explicit sampling conventions and a reference whose limitations are understood. Established applications provide the numerical methods; guidance helps select their inputs, connect their outputs, and identify questions that remain unresolved.

Researcher involvement was substantive. The sequence example required intervention to adopt an established simulator, and reconstruction did not improve agreement over zero-filled RSS. These observations place the toolbox within supervised research practice. The value illustrated is an inspectable account of decisions and checks, rather than evidence of autonomous scientific discovery or consistently superior reconstruction.

Project memory extends this account across sessions. Self-Refine studies revision through textual feedback, and Reflexion retains feedback across attempts [@selfrefine;reflexion]. MRFoundry uses written project records to retain a lesson together with the evidence that limits its scope. Whether this improves later work requires longitudinal comparisons that measure retrieval, application, and resulting outcomes. Memory reuse and community contributions were not isolated here.

### 4.3 Evaluation scope and future work

Tasks were agent-authored within an author-selected scope; Core shares problem structure with development tasks, and independent expert review is incomplete. One run per Core task–model combination does not establish repeated-run reliability. Hard coverage differs, and nominal reasoning settings do not equalize provider budgets. Automated checks measure specified outputs, not researcher effort, judgment, or clinical validity. Historical model snapshots, full execution configurations, and per-run resource exposure are unavailable. Setup incidents, shared resources, and the retained grading weakness further limit interpretation.

Future evaluation should add independent task review, repeated runs, and complete execution records, and test whether guidance transfers to new acquisition conditions and host environments. Longitudinal studies can assess whether recorded lessons improve subsequent decisions and whether reviewed contributions preserve that benefit across projects. The present demonstrations lack matched baselines and establish neither scanner safety nor diagnostic benefit. MRI Agent Bench provides an accompanying resource for studying task completion, while broader research and clinical outcomes require their own evaluation designs.

## 5 Conclusion

MRFoundry connects MRI knowledge, established software, and researcher supervision through reusable skills and evidence-linked project records. The demonstrations document a later skill-guided sequence audit and guidance use during reconstruction. Alongside the toolbox, MRI Agent Bench supports paired assessment of verified task completion. The Core comparison supports domain guidance under tested conditions; benefits from memory reuse and shared contributions remain unmeasured.

## Data and software availability

MRFoundry source and contribution guidance are available at https://github.com/KeWang0622/MRFoundry [@mrfoundry;contributing], with the evaluated snapshot preserved separately [@mrfoundry014]. The reference index and tutorial provide entry points [@mrfoundryindex;mrfoundrytutorial]. MRI Agent Bench publishes Core tasks, data, checkers, and result exports [@blochbenchtasks;blochbench]. Hard materials, per-task outcomes, and traces remain private; only aggregates are reported. The [paper evidence directory](https://github.com/KeWang0622/MRFoundry/tree/main/paper/evidence) supplies original demonstration scripts, reports, input identities, recorded environments, and historical evaluation settings, with gaps and reproduction limits stated explicitly. Raw data remain in their original releases; M4Raw Brain v1.6 is CC BY 4.0 [@m4rawdata].

## AI assistance disclosure

AI tools supported software development, writing, and explanatory illustrations under the author's direction. Scientific MRI images and quantitative plots derive from recorded data and numerical outputs without generative enhancement. The author is responsible for the scientific content and final manuscript.
