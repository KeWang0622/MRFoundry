# MRFoundry paper

Current working manuscript: **MRFoundry: Knowledge-Guided Agent Loops for End-to-End MRI Research**. This is an author-side draft in the supplied MRM template, not a submitted or accepted article.

- [Read the manuscript](latex/manuscript.pdf).
- [Offline comparison tables](supporting-information/SI-offline-evaluation.pdf), [evaluation protocol](supporting-information/SI-offline-protocol.pdf), and [MRI demonstration evidence](supporting-information/SI-workflow-evidence.pdf).
- [Original evidence and reproduction limits](evidence/README.md).
- [Editable figure sources](figures/): each figure folder contains its current PowerPoint, publication PDF, PNG and rebuild instructions.
- [Source-package guide](SOURCE-PACKAGE.md), [citation audit](CITATION-AUDIT.md), and [author decisions before submission](AUTHOR_CONFIRMATIONS.md).

The toolbox and benchmark have distinct scopes: [MRFoundry](https://github.com/KeWang0622/MRFoundry) provides MRI guidance for existing agents; [MRI Agent Bench](https://github.com/KeWang0622/MRIAgentBench) maintains executable tasks and public result exports. This paper introduces MRI Agent Bench alongside MRFoundry and uses it for a bounded comparison.

Figures 2–5 reuse the original Figure 1 researcher illustrations; agent artwork and scientific panels are preserved.

The main paper is 12 native MRM pages, including five figures, two tables and references; Supporting Information is separate. The body contains 3,311 words (including availability and disclosure), within the 3,500-word Toolbox limit; the abstract contains 177 words. The exact evaluated snapshot appears in the methods references and Supporting Information; it is not the current toolbox release number. Saved numerical outcomes are preserved. Public material includes Core tasks/results and the approved demonstration evidence; private Hard task identities, scoring materials, per-task outcomes and traces are excluded.

The evidence directory was published at [MRFoundry commit d125b9c](https://github.com/KeWang0622/MRFoundry/tree/d125b9c43904f84a10a178d08b11b25300325d8e/paper/evidence). Historical numerical-provenance files retain their original draft numbers and paths for traceability; the links above identify current entry points.

## Rebuild

In the portable source archive, install the dependencies described in `build/README.md`, then run from the extracted `MRFoundry-paper/` directory:

```bash
bash build/build.sh --output-dir "$PWD" --figure-root "$PWD"
```

This assembles saved text, tables and figures. It does not run agent trials, MRI calculations, grading or statistical resampling. See [SOURCE-PACKAGE.md](SOURCE-PACKAGE.md) for the distinction between rebuilding the paper and reproducing the scientific runs.
