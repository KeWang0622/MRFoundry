# MRFoundry paper

Current working manuscript: **MRFoundry: Knowledge-Guided Agent Loops for End-to-End MRI Research**. This is an author-side draft in the supplied MRM template, not a submitted or accepted article.

- [Read the manuscript](latex/manuscript.pdf).
- [Offline comparison tables](supporting-information/SI-offline-evaluation.pdf), [evaluation protocol](supporting-information/SI-offline-protocol.pdf), and [MRI demonstration evidence](supporting-information/SI-workflow-evidence.pdf).
- [Original evidence and reproduction limits](evidence/README.md).
- [Editable figure sources](figures/): each figure folder contains its current PowerPoint, publication PDF, PNG and rebuild instructions.
- [Source-package guide](SOURCE-PACKAGE.md), [citation audit](CITATION-AUDIT.md), and [author decisions before submission](AUTHOR_CONFIRMATIONS.md).

The toolbox and benchmark have distinct scopes: [MRFoundry](https://github.com/KeWang0622/MRFoundry) provides MRI guidance for existing agents; [MRI Agent Bench](https://github.com/KeWang0622/MRIAgentBench) maintains executable tasks and public result exports. This paper introduces MRI Agent Bench alongside MRFoundry and uses it for a bounded comparison.

Figures 2–5 reuse the original Figure 1 researcher illustrations; agent artwork and scientific panels are preserved.

Revision 54 expands and reorganizes the manuscript narrative. Figure visuals, all numerical result cells and original scientific evidence remain unchanged. Technical clarifications acknowledge bundled helper scripts, pin five current MRFoundry source references to the verified repository snapshot, distinguish the fixed evaluation snapshot, and specify the S0 value used for diffusion-signal prediction. These reporting corrections do not rerun or change the saved experiments. The manuscript contains 3,491 body words, a 174-word abstract and 13 pages in the supplied MRM template. The exact evaluated snapshot remains distinct from the current toolbox source snapshot. Public material includes Core tasks/results and the approved demonstration evidence; private Hard task identities, scoring materials, per-task outcomes and traces are excluded.

The evidence directory was published at [MRFoundry commit d125b9c](https://github.com/KeWang0622/MRFoundry/tree/d125b9c43904f84a10a178d08b11b25300325d8e/paper/evidence). Historical numerical-provenance files retain their original draft numbers and paths for traceability; the links above identify current entry points.

Historical section references are retained for provenance: sequence 3.1.1 → 3.1, reconstruction 3.1.2 → 3.2, research lesson 3.2 → 3.3, and benchmark comparison 3.3 → 3.4.

## Rebuild

In the portable source archive, install the dependencies described in `build/README.md`, then run from the extracted `MRFoundry-paper/` directory:

```bash
bash build/build.sh --output-dir "$PWD" --figure-root "$PWD"
```

This assembles saved text, tables and figures. It does not run agent trials, MRI calculations, grading or statistical resampling. See [SOURCE-PACKAGE.md](SOURCE-PACKAGE.md) for the distinction between rebuilding the paper and reproducing the scientific runs.
