# Supporting numerical report — MRFoundry revision 43

These are unchanged checks from three recorded MRI demonstrations. The sequence example appears in Figure 3 and the acquired-data reconstruction example in Figure 4. The independent diffusion example appears in Supporting Information S2. These checks are supporting evidence, not new experiments or a cross-task score. Raw values, source JSON pointers and hashes are preserved in supporting-numerical-evidence.json and supporting-numerical-provenance.md.

The evidence JSON is a verbatim historical record. Its former table/figure numbers and editing notes do not describe the current layout: revision 43 uses Figures 3 and 4 for the two worked examples, Supporting Information S2 for diffusion and extended diagnostics, and Table 2/Figure 5 for the controlled comparison. Numerical evidence in that JSON remains unchanged; the report below provides the current presentation.

## A Sequence design and temporal-step check

Simulation-only prototype; 128 spokes × 64 ADC samples. The temporal-step check uses the same 13,497-spin phantom. Supporting Information S2.1 distinguishes the original researcher-supervised construction from the later sequence audit; later skill retrieval does not establish historical retrieval during construction.

| Check | Observed | Target or comparison |
| --- | --- | --- |
| TE / TR (ms) | 5.000 / 15.000 | 5 / 15 (target) |
| Timing errors (count) | 0 | PyPulseq readback |
| Peak gradient (mT/m) | 12.735 | 32 (limit) |
| Peak slew (T/m/s) | 125.266 | 130 (limit) |
| Trajectory difference (cycles/m) | 0.00162 | Exported vs prewrite |
| RF-step signal change (%) | 0.07096 | 10 to 5 microseconds |

Sources: [pypulseq](https://doi.org/10.21105/joss.01725), [pulseq](https://doi.org/10.1002/mrm.26235), [koma](https://doi.org/10.1002/mrm.29635), [winkelmann](https://doi.org/10.1109/TMI.2006.885337).

## B Acquired-data reconstruction

One M4Raw slice; 195 source phase-encoding lines, 24 central retained lines, common ESPIRiT maps and solver settings. Supporting Information S2.2 retains the complete initial-SENSE, final-L1 and zero-filled comparison, plus implementation history and residual definitions. The 195-line denominator was used from the initial implementation.

| Metric | 110 retained lines | 67 retained lines |
| --- | --- | --- |
|  | Effective R = 1.77 | Effective R = 2.91 |
| L1 magnitude discrepancy (%) | 30.33 | 33.62 |
| Zero-filled RSS discrepancy (%) | 21.24 | 28.92 |
| Sampled-data residual (%) | 30.88 | 24.84 |
| Withheld-source residual (%) | 85.72 | 91.38 |
| 200-to-400-iteration change (%) | 0.0477 | 0.0741 |

Sources: [m4raw](https://doi.org/10.1038/s41597-023-02181-4), [m4rawdata](https://doi.org/10.5281/zenodo.8056074), [m4format](https://huggingface.co/datasets/mylyu/M4Raw_brain/blob/v1.6.0/H5_FORMAT.md), [sigpy](https://cds.ismrm.org/protected/19MProceedings/PDFfiles/4819.html), [sigpydocs](https://github.com/mikgroup/sigpy/blob/v0.1.27/sigpy/mri/app.py), [espirit](https://doi.org/10.1002/mrm.24751), [sense](https://doi.org/10.1002/(SICI)1522-2594(199911)42:5<952::AID-MRM16>3.0.CO;2-S), [sparsemri](https://doi.org/10.1002/mrm.21391).

## C Diffusion tensor analysis

One Stanford HARDI subject; 160 volumes (10 b=0; 150 b=2000 s/mm²), fixed tensor/WLS fit. The source inspection, 3D masking procedure, recorded maps, numerical results and interpretation are retained in Supporting Information S2.3.

| Slice index | Mask voxels | Median fit residual (%) |
| --- | --- | --- |
| 30 | 4,799 | 10.24 |
| 38 | 4,834 | 8.95 |
| 46 | 4,365 | 9.05 |

Sources: [stanfordhardi](https://purl.stanford.edu/yx282xq2090), [dipy](https://doi.org/10.3389/fninf.2014.00008), [basser](https://doi.org/10.1016/S0006-3495(94)80775-1), [chungwls](https://doi.org/10.1016/j.neuroimage.2006.07.001), [dipysource](https://github.com/dipy/dipy/blob/1.12.1/dipy/reconst/dti.py).

A. TE/TR are mean readback values; trajectory difference is the maximum absolute coordinate difference. Gradient and slew peaks are per axis. RF-step change uses the 5-µs signal norm across 8,192 samples. These checks establish neither scanner readiness nor spatial convergence.
B: R = 195 / retained source lines. Full-matrix magnitude discrepancies use noisy all-source RSS. Complex-data residuals and iteration change are defined in Supporting Information S2.2 and use common source normalization; the main comparison is in Section 3.1.2. The L1 outputs have greater discrepancy than zero-filled RSS.
C: Zero-based slices from one subject. Residuals summarize model agreement across all 160 volumes, with denominator max(||S||₂, 1) in source intensity units and outcomes in Supporting Information S2.3; they do not establish biological validity.

## Metric definitions

RF-step change is ||S_5us − S_10us||₂ / ||S_5us||₂ over 8,192 samples. Magnitude discrepancy compares each displayed reconstruction with the noisy all-source RSS image. Complex-data residuals use the sampled or withheld source measurements as the denominator; withheld lines do not enter the solve. Iteration change is ||x400 − x200||₂ / ||x400||₂. Diffusion fit residual is ||predicted − measured||₂ / max(||measured||₂, 1) across all 160 volumes. The denominator floor is inactive in every evaluated mask voxel; saved-array lower bounds on the measured norm are 50.91, 36.37, and 68.62 for slices 30, 38, and 46.
