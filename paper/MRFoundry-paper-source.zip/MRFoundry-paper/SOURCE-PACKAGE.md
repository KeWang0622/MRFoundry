# Portable paper source

The archive has one root, `MRFoundry-paper/`. Its `package-inventory.json` lists included files and SHA-256 digests. The accompanying package-verification receipt reports the checks actually completed for that exact archive.

## Contents

- Markdown manuscript, bibliography, structured captions/tables and native MRM LaTeX source/PDF.
- Five editable PowerPoint figures, publication PDFs, PNG previews and retained source arrays.
- Supporting Information in Markdown and PDF with its renderer.
- Original demonstration scripts, reports, input identities, recorded environments and historical evaluation settings.
- Figure and citation provenance, rebuild tools and exact template compatibility patch.

The original MRM class and supporting styles are unchanged. A separately named bibliography style corrects field and author-name handling; `latex/MRM-AMA-compatibility.patch` records the differences. Figure 1 preserves its original drawing streams with a localized brand-logo overlay; Figures 2–5 restore their original publication PDFs exactly. The prior agent artwork is retained throughout. Their PowerPoint files were also inspected in the native application; native-export PDFs are QA artifacts rather than the publication source.

## Building the document

Use Python 3.9+, the packages in `build/requirements-package.txt`, Tectonic and Poppler. From the extracted root:

```bash
bash build/build.sh --output-dir "$PWD" --figure-root "$PWD"
```

Each figure's `REBUILD.md` explains how to reproduce the current figure from its packaged baseline and assets, including Figure 1's brand-only overlay. Supporting Information has its own [rebuild instructions](supporting-information/REBUILD.md). These are document/figure builds, not scientific experiments.

## Scientific reproduction limits

The [evidence README](evidence/README.md) distinguishes original byte-preserved records from later audits and display tools. Original demonstration scripts retain historical workspace and packaging assumptions; a clean-environment scientific rerun has not been validated. Source datasets are linked to their public releases and checksums rather than redistributed. Some historical model/backend settings and resource-policy exposures were not retained. Rebuilding this PDF therefore does not establish independent reproduction of the model comparison or MRI experiments.

The public package excludes raw agent conversations, private Hard tasks/scorers/identities and per-task results, unpublished later evaluation rounds, caches and superseded design concepts. Retained numerical-provenance documents may name historical local records; their mention does not imply those records are publicly included. Licenses and attribution for public input data are documented in [INPUTS-AND-LICENSES.md](evidence/INPUTS-AND-LICENSES.md).

Author-side review is separate from journal peer review. Pending authorship, support and editor-permission decisions are recorded in [AUTHOR_CONFIRMATIONS.md](AUTHOR_CONFIRMATIONS.md).
