# Portable paper source

The title page now lists Ke Wang and Molin Zhang as Independent Researchers, and Atakan Topcu and Hossein Momeni with the Department of Electrical Engineering and Computer Sciences, University of California, Berkeley. Ke Wang remains the corresponding author. The PDF author metadata and running head match the author list. Coauthor contact addresses are retained in LaTeX source comments. Manuscript prose, numerical results, figures, tables, references and Supporting Information are unchanged.

The current author amendment is documented in `authors-amendment.json`. Previous Figure 3 and editorial review records remain historical; this amendment does not rerun their scientific or visual checks.

Figure 3 connector correction: the researcher-feedback route is connected at its left origin and routed into the KomaMRI check panel. The outgoing results connection is kept separate. All scientific-panel text and values, manuscript prose, tables, references, Supporting Information, evidence and other figure artwork are unchanged. The earlier Figure 3 amendment identifies that correction; original v54 reviews remain historical records of the pre-correction artifact.

The revision-54 review and provenance description below refers to the original pre-correction artifact. It does not independently approve the connector correction.

The archive has one root, `MRFoundry-paper/`. Its `package-inventory.json` lists included files and SHA-256 digests. The accompanying package-verification receipt reports the checks actually completed for that exact archive.

## Contents

- Markdown manuscript, bibliography, structured captions/tables and native MRM LaTeX source/PDF.
- Five editable PowerPoint figures, publication PDFs, PNG previews and retained source arrays.
- Supporting Information in Markdown and PDF with its renderer.
- Original demonstration scripts, reports, input identities, recorded environments and historical evaluation settings.
- Figure and citation provenance, rebuild tools and exact template compatibility patch.

The original MRM class and supporting styles are unchanged. A separately named bibliography style corrects field and author-name handling; `latex/MRM-AMA-compatibility.patch` records the differences. In the original revision-54 package, all five figure visuals and their publication PDF/PNG bytes were identical to revision 53, and Figure 2–5 speaker notes received exact terminology, raster-provenance and secondary-analysis corrections through narrowly scoped XML replacements; historical baseline PowerPoint files remain unchanged. In that revision, Figures 2–5 reused the original Figure 1 researcher illustrations in human-role slots through native PowerPoint picture objects and localized publication-PDF overlays. Original drawing streams, scientific panels and agent artwork are retained. The v53 PowerPoint visual inspection remains historical; those note-only changes were verified by exact visual-part equality and schema checks. No new native-app inspection is claimed. Native-export PDFs are QA artifacts rather than the publication source.

In the original revision-54 package, figure visuals, numerical result cells and original scientific evidence were unchanged. Its technical clarifications acknowledge bundled helper scripts, pin five current MRFoundry source references to the verified repository snapshot, distinguish the fixed evaluation snapshot, and specify the S0 value used for diffusion-signal prediction. These reporting corrections do not rerun or change the saved experiments. The exact before/after files and semantic checks are recorded in `provenance/pre-arrow-technical-preservation-exceptions.json` and `build/technical_changes.py`. The later Figure 3 correction and current author addition are documented separately in their amendment receipts.

## Building the document

Use Python 3.9+, the packages in `build/requirements-package.txt`, Tectonic and Poppler. From the extracted root:

```bash
bash build/build.sh --output-dir "$PWD" --figure-root "$PWD"
```

Each figure's `REBUILD.md` explains how to reproduce the current figure from its packaged baseline and assets, including the unchanged Figure 1 artwork and localized researcher replacements. Supporting Information has its own [rebuild instructions](supporting-information/REBUILD.md). These are document/figure builds, not scientific experiments.

## Scientific reproduction limits

The [evidence README](evidence/README.md) distinguishes original byte-preserved records from later audits and display tools. Original demonstration scripts retain historical workspace and packaging assumptions; a clean-environment scientific rerun has not been validated. Source datasets are linked to their public releases and checksums rather than redistributed. Some historical model/backend settings and resource-policy exposures were not retained. Rebuilding this PDF therefore does not establish independent reproduction of the model comparison or MRI experiments.

The public package excludes superseded avatar baselines, raw agent conversations, private Hard tasks/scorers/identities and per-task results, unpublished later evaluation rounds, caches and superseded design concepts. Retained numerical-provenance documents may name historical local records; their mention does not imply those records are publicly included. Licenses and attribution for public input data are documented in [INPUTS-AND-LICENSES.md](evidence/INPUTS-AND-LICENSES.md).

Author-side review is separate from journal peer review. Pending authorship, support and editor-permission decisions are recorded in [AUTHOR_CONFIRMATIONS.md](AUTHOR_CONFIRMATIONS.md).
