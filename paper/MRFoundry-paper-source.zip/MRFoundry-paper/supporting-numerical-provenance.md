# Demonstration evidence provenance — revision 43

The numerical evidence JSON is copied unchanged from the November 3 handoff. No fit, reconstruction or experiment was rerun. Figure 3 presents the recorded sequence workflow and a display of saved KomaMRI signal values. Figure 4 presents the recorded acquired-data reconstruction workflow. The independent diffusion example and extended diagnostics remain in Supporting Information S2.

`supporting-numerical-evidence.json` is a verbatim historical evidence record, originally named `table2-plan.json`. Its version, former table/figure numbers, layout instructions and prose-editing notes describe that earlier draft, not revision 43. In this revision the sequence and reconstruction examples appear in Figures 3 and 4; diffusion appears in Supporting Information S2. All three retain their numerical reference here. Table 2 and Figure 5 report the controlled evaluation, with Figure 5 restricted to aggregate outcomes. The historical JSON is preserved byte-for-byte so its numerical values, source pointers and provenance remain unchanged.

## Frozen source identity

- `sequence`: `outputs/mrm-toolbox/sequence-evidence-v22/sequence-audit.json`
  - SHA256: `2109f285fc147c52524497bc3b7a9d49522fcdaea81379ec8a333e567f612ff5`
- `reconstruction`: `outputs/mrm-toolbox/real-data-v19/m4raw/report.json`
  - SHA256: `ea0cb0adb2708b8409ca078fd5e46ce70f546a765a85b3ff6301f42a93e1e4fc`
- `diffusion`: `outputs/mrm-toolbox/real-data-v19/dwi/report.json`
  - SHA256: `5f7ff7f8789ae48d94f6d88784c68daba9e6fbfa5002a268a957ffba508ba8d5`
- `reconstruction_code`: `outputs/mrm-toolbox/real-data-v19/code/finalize_evidence.py`
  - SHA256: `ef1412cd9bf30181332c44f2f70d3db6182134bf596ab69ad483b4933a02e16a`
- `diffusion_code`: `outputs/mrm-toolbox/real-data-v19/code/run_dwi.py`
  - SHA256: `6a956ee1c499e54e75b08555d12958ba0aa4299b1b63fd5def68bfbd3d1fc748`
- `sequence_code`: `outputs/mrm-toolbox/sequence-evidence-v22/extract_sequence_evidence.py`
  - SHA256: `f5e823f11c4003b5243f253e88cbdb3dc592b58c87e786c1ba06f52d9a5ce0fb`

The three report hashes exactly match the already frozen v22 evidence index. Every numeric cell in `supporting-numerical-evidence.json` carries its source, JSON pointer, full raw value and rounded display text. The sequence audit, acquired reconstructions and diffusion analysis remain distinct demonstrations. Source paths identify retained historical files. The Figure 3 folder includes a frozen copy of the sequence audit, original native waveform/trajectory artwork and saved signal array. The Figure 4 folder includes a frozen report subset, exact masks and original image bytes. The workflow supplement includes the original diffusion inspection image. Original reconstruction/diffusion source scripts and full historical environments remain separately retained; the portable figure package does not claim to reproduce them.

## Formula checks against retained scripts

- Sequence RF-step change uses `||S_5us-S_10us||₂ / ||S_5us||₂`; same saved 8,192-sample coarse-phantom signal. The trajectory value is a maximum absolute coordinate difference in cycles/m, not a relative accuracy percentage.
- Reconstruction code `finalize_evidence.py`, lines 34–42, defines complex iteration change with x400 in the denominator, full-matrix magnitude discrepancy, sampled complex residual and source-withheld residual. The withheld mask is not used in the solve. ZF results are retained from the original report, not rerun.
- Source RSS/provider agreement 8.848532218053151e-8 is shared across both reconstruction masks. Keep its rounded 8.85e-8 in prose or a shared block note rather than duplicate it in each condition.
- `run_dwi.py` line35 includes a denominator safeguard: `max(||S||₂,1)` in source intensity units. The frozen report abbreviates this to a relative L2 residual. The exact safeguard appears in the supporting numerical report's metric definitions. The saved `denominator_floor_verification` field in `supporting-numerical-evidence.json` records a read-only array check establishing that it is inactive in every evaluated mask; no residual calculation or fitting was rerun.
- DWI values are medians over each saved mask and all 160 volumes. Three slices from one subject must not be described as three independent subjects or a cohort.

## Non-negotiable interpretation

- L1 magnitude discrepancy is worse than the zero-filled RSS comparator at both retained-line settings; the table must preserve that fact.
- Tiny 200-to-400-iteration changes do not make the large sampled/withheld residuals disappear or establish anatomical fidelity.
- Programmed gradient/slew limits are configured software bounds, not measured hardware certification. RF-step sensitivity is temporal only; no full spatial or physical-model convergence follows.
- Residuals across different task blocks are different measurements. No aggregate score, success rate, agent advantage or recursive-improvement benefit is supported.


## Workflow attribution and current supporting material

The sequence construction was researcher-supervised, including a requested switch from an initial custom simulator to KomaMRI. The later audit documents skill retrieval at audit time only; no historical construction-time skill read is inferred. Reconstruction guidance reads are recorded during the acquired-data run. The reconstruction scripts use 195 acquired lines from their first retained implementation; the record does not show an earlier 256-line denominator error. These provenance limits are stated in Supporting Information S2.

The main manuscript's controlled results remain separate from these demonstrations. Supporting Information S1 and its S7 protocol addendum retain the domain/cohort outcomes, token definitions, setup incidents and grading limitations. No public text introduces private Hard task identities or per-task traces.
