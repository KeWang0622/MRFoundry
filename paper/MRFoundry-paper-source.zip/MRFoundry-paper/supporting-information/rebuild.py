"""Render public-safe Markdown supplements. No scientific calculations are run."""
from pathlib import Path
import argparse, re, html, json, hashlib
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image, KeepTogether
from reportlab.lib.utils import ImageReader
from pypdf import PdfReader

HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
DEFAULT_ROOT=HERE if (HERE/'SI-workflow-evidence.md').exists() else HERE.parents[1]/'outputs/MRFoundry-paper-v43/supporting-information'
parser.add_argument('--root',type=Path,default=DEFAULT_ROOT)
args=parser.parse_args();root=args.root.resolve()
PAGE_W,PAGE_H=A4
MARGIN=48
WIDTH=PAGE_W-2*MARGIN
ink=colors.HexColor('#1e2933');blue=colors.HexColor('#244862');grey=colors.HexColor('#eaf0f3')
styles={
 'body':ParagraphStyle('body',fontName='Times-Roman',fontSize=10.0,leading=12.6,textColor=ink,spaceAfter=7),
 'title':ParagraphStyle('title',fontName='Helvetica-Bold',fontSize=14,leading=17,textColor=blue,spaceAfter=10),
 'heading':ParagraphStyle('heading',fontName='Helvetica-Bold',fontSize=10.7,leading=13.4,textColor=blue,spaceBefore=6,spaceAfter=7),
 'small':ParagraphStyle('small',fontName='Times-Roman',fontSize=8.4,leading=10.5,textColor=ink,spaceAfter=7),
 'cell':ParagraphStyle('cell',fontName='Times-Roman',fontSize=9.3,leading=11.5,textColor=ink),
 'header':ParagraphStyle('header',fontName='Helvetica-Bold',fontSize=8.7,leading=10.5,textColor=ink)
}
def inline(s):
 s=html.escape(s)
 s=re.sub(r'`([^`]+)`',r'\1',s)
 s=re.sub(r'\[([^\]]+)\]\((https?://(?:[^()]|\([^()]*\))*)\)',lambda m:'<link href="'+m[2]+'" color="#244862">'+m[1]+'</link>',s)
 s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
 s=s.replace('mm^2','mm<super>2</super>')
 s=re.sub(r'10\^(-?\d+)',r'10<super>\1</super>',s)
 s=re.sub(r'\bL2\(',r'L<sub>2</sub>(',s)
 return s

def make_table(rows):
 cells=[[x.strip() for x in line.strip().strip('|').split('|')] for line in rows]
 cells=[cells[0]]+cells[2:]
 n=len(cells[0]);weights=([.47,.22,.31] if 'Recorded check' in cells[0][0] else [.60,.20,.20]) if n==3 else [1/n]*n
 data=[[Paragraph(inline(v),styles['header' if i==0 else 'cell']) for v in row] for i,row in enumerate(cells)]
 t=Table(data,colWidths=[WIDTH*w for w in weights],hAlign='LEFT',repeatRows=1)
 t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(-1,0),grey),('LINEABOVE',(0,0),(-1,0),.8,blue),('LINEBELOW',(0,0),(-1,0),.5,blue),('LINEBELOW',(0,-1),(-1,-1),.6,blue),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5)]))
 return [t,Spacer(1,9)]

def footer(canvas,doc):
 canvas.saveState();canvas.setStrokeColor(colors.HexColor('#bcc7cd'));canvas.setLineWidth(.45);canvas.line(MARGIN,36,PAGE_W-MARGIN,36)
 canvas.setFont('Helvetica',8);canvas.setFillColor(blue);canvas.drawString(MARGIN,24,doc.short_title);canvas.drawRightString(PAGE_W-MARGIN,24,str(doc.page));canvas.restoreState()

def build(stem,label,expected):
 source=root/(stem+'.md');lines=source.read_text().splitlines();story=[];i=0
 while i<len(lines):
  line=lines[i].strip()
  if not line:i+=1;continue
  if line=='---':story.append(PageBreak());i+=1;continue
  if line.startswith('|'):
   block=[]
   while i<len(lines) and lines[i].strip().startswith('|'):block.append(lines[i]);i+=1
   story.extend(make_table(block));continue
  if line.startswith('!['):
   rel=re.search(r'\]\(([^)]+)\)',line)[1];path=root/rel;w,h=ImageReader(str(path)).getSize();story.append(Image(str(path),width=WIDTH,height=WIDTH*h/w));story.append(Spacer(1,5));i+=1;continue
  if line.startswith('# '):story.append(Paragraph(inline(line[2:]),styles['title']));i+=1;continue
  if line.startswith('## '):story.append(Paragraph(inline(line[3:]),styles['heading']));i+=1;continue
  parts=[line];i+=1
  while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','![')) and lines[i].strip()!='---':parts.append(lines[i].strip());i+=1
  txt=' '.join(parts);style=styles['small'] if txt.startswith(('Sources:','Figure S2.1.')) else styles['body'];story.append(Paragraph(inline(txt),style))
 output=root/(stem+'.pdf');doc=SimpleDocTemplate(str(output),pagesize=A4,leftMargin=MARGIN,rightMargin=MARGIN,topMargin=43,bottomMargin=49,title=label,author='Ke Wang',subject='MRFoundry supporting information')
 doc.short_title=label;doc.build(story,onFirstPage=footer,onLaterPages=footer)
 count=len(PdfReader(output).pages)
 assert count<=expected,f'{stem}: {count} pages exceeds {expected}'
 return {'markdown_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'pdf_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'pages':count}
if __name__=='__main__':
 report={}
 for stem,label,maxpages in [('SI-workflow-evidence','MRFoundry | Supporting Information S2',4),('SI-offline-protocol','MRFoundry | Supporting Information S1, S7',4),('SI-offline-evaluation','MRFoundry | Supporting Information S1',4)]:report[stem]=build(stem,label,maxpages)
 (root/'supporting-build-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
