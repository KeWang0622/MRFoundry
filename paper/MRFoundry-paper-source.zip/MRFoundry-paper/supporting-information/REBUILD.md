# Rebuild Supporting Information

Install requirements.txt in an isolated Python environment, then run:

```bash
python rebuild.py
```

The renderer reads SI-offline-evaluation.md, SI-offline-protocol.md, SI-workflow-evidence.md and the saved diffusion image under assets/. It writes their three PDF companions and a hash/page-count receipt. It performs no scientific calculations and preserves all saved table values. Each document is limited to four pages. Render and inspect every page after an edit.

The earlier SI-offline-evaluation.tex is retained historical source; the current Markdown is the source for the current PDF. Numerical source JSON and provenance are in the parent directory.
