# Supporting Information S1

Offline paired evaluation of MRFoundry 0.14.0

This supplement reports saved offline comparisons of the same agent with and without MRFoundry 0.14.0 (commit bd49b95). A paired trial consists of one attempt per arm with matched model, tools, inputs and nominal budgets, subject to the resource-policy caveats in S7.4. Verified completion requires every automated grader check to pass. This document introduces no new model execution or grading.

## Study design

Core includes one sealed instance of each of 24 task types for ten models: 240 paired trials. Hard contains 15 task types: 11 multi-stage and four system-design types. Three models cover all 15 types with two instances each (90 pairs); four further models cover the 11 multi-stage types with one instance each (44 pairs). The resulting 134 Hard pairs are not a uniform model leaderboard. Hard task identities and materials remain private.

## Table S1. Aggregate completion and paired effects

| Set | Pairs | Without -> with | Change, pp | 95% CI, pp | P |
| --- | --- | --- | --- | --- | --- |
| Core | 240 | 162/240 -> 188/240 | +10.8 | [+0.8, +21.2] | 0.0004 |
| Hard | 134 | 49/134 -> 60/134 | +8.2 | [-3.9, +19.7] | 0.061 |

Intervals are the saved 95% two-way cluster bootstrap over task types and models (4,000 resamples, seed 0). P values are saved secondary, unclustered exact two-sided McNemar comparisons, which assume independent discordant-pair signs and do not adjust for task/model clustering (see S7.3). Core discordant pairs are 39 with-only and 13 without-only; Hard discordant pairs are 20 and 9. The Hard cluster-bootstrap interval includes zero.

## Scope and recorded limitations

- No web search was available in the offline evaluation. Only Core and Hard are reported; internal later-round data are excluded.

- One additional model was excluded after its API rejected the host file-editing tool; nine started pairs are outside the analysis.

- A runner setup failure affected 143 pair setups before either arm reached a model turn (94 Core, 49 Hard). These were restarted without changing the task or model condition.

- An 8 GiB per-process memory cap began partway through the runs. Recorded settings matched the cap within newly prepared pairs; exposure records are incomplete and resources were not uniform across the complete study. S7.4 details the policy changes and documentation limits.

- One Hard task has an image subcheck that accepts a zero-filled reconstruction on one instance. Its identity is withheld; the aggregate scores remain the originally recorded scores.

Model and domain summaries below are descriptive. Their different coverage and the exploratory breakdowns do not establish a general model ranking or corrected multiple-comparison claims.


---

# Core: full matched coverage

24 task types per model; 240 paired trials

## Table S2. Core completion by domain

| Domain | Pairs | Without -> with | With-only / without-only |
| --- | --- | --- | --- |
| Diffusion | 20 | 17/20 -> 15/20 | 0 / 2 |
| Functional MRI | 10 | 8/10 -> 9/10 | 1 / 0 |
| Hardware / field | 20 | 13/20 -> 14/20 | 3 / 2 |
| Perfusion / CEST | 20 | 14/20 -> 18/20 | 4 / 0 |
| Reconstruction | 20 | 13/20 -> 15/20 | 4 / 2 |
| Relaxometry / QSM | 20 | 13/20 -> 19/20 | 6 / 0 |
| Sequence design | 70 | 34/70 -> 45/70 | 14 / 3 |
| Spectroscopy | 10 | 8/10 -> 8/10 | 1 / 1 |
| Study design / statistics | 20 | 17/20 -> 17/20 | 2 / 2 |
| Writing / review | 30 | 25/30 -> 28/30 | 4 / 1 |

Diffusion decreased from 17 to 15 passes across 20 paired trials. Domain denominators differ because each domain contains a different number of task types.

## Table S3. Core completion by model (alphabetical)

| Model | Pairs | Without -> with | With-only / without-only |
| --- | --- | --- | --- |
| Claude Haiku 5.5 | 24 | 15/24 -> 19/24 | 7 / 3 |
| Claude Opus 5.5 | 24 | 22/24 -> 22/24 | 1 / 1 |
| Claude Sonnet 5.5 | 24 | 17/24 -> 23/24 | 6 / 0 |
| Gemini 3.8 Flash | 24 | 19/24 -> 22/24 | 4 / 1 |
| Gemini 4 Argon | 24 | 21/24 -> 24/24 | 3 / 0 |
| GPT-5.3 Codex | 24 | 9/24 -> 13/24 | 5 / 1 |
| GPT-6.1 Sol | 24 | 19/24 -> 22/24 | 3 / 0 |
| GPT-6.1 Terra | 24 | 22/24 -> 22/24 | 2 / 2 |
| Kimi K3 | 24 | 13/24 -> 16/24 | 6 / 3 |
| MAI Code 1.1 Flash | 24 | 5/24 -> 5/24 | 2 / 2 |

All models have identical task-type coverage in Core. Seven models improved in pass count, three were unchanged, and none declined in aggregate. These totals can conceal task-specific gains and losses, which are retained in the discordant-pair counts.


---

# Hard: separate coverage cohorts

Different task coverage is reported explicitly

## Table S4a. Full coverage: 15 task types, two instances each

Three models; 30 paired trials per model. Cohort total: 44/90 without skills and 52/90 with MRFoundry.

| Model | Pairs | Without -> with | With-only / without-only |
| --- | --- | --- | --- |
| Claude Opus 5.5 | 30 | 16/30 -> 20/30 | 5 / 1 |
| Gemini 4 Argon | 30 | 13/30 -> 14/30 | 5 / 4 |
| GPT-6.1 Sol | 30 | 15/30 -> 18/30 | 6 / 3 |

## Table S4b. Multi-stage coverage: 11 types, one instance each

Four models; 11 paired trials per model. Cohort total: 5/44 without skills and 8/44 with MRFoundry. Models are alphabetical within each cohort, not ranked across cohorts.

| Model | Pairs | Without -> with | With-only / without-only |
| --- | --- | --- | --- |
| Claude Haiku 5.5 | 11 | 2/11 -> 3/11 | 2 / 1 |
| Gemini 3.8 Flash | 11 | 2/11 -> 4/11 | 2 / 0 |
| GPT-5.3 Codex | 11 | 1/11 -> 1/11 | 0 / 0 |
| MAI Code 1.1 Flash | 11 | 0/11 -> 0/11 | 0 / 0 |

## Table S5. Hard completion by task class

| Task class | Pairs | Without -> with | With-only / without-only |
| --- | --- | --- | --- |
| Multi-stage (11 types) | 110 | 48/110 -> 57/110 | 18 / 9 |
| System design (4 types) | 24 | 1/24 -> 3/24 | 2 / 0 |

## Table S6. Reported token use (with / without)

| Set | Total tokens ratio | Tokens per verified success |
| --- | --- | --- |
| Core | 1.048 | 0.903 |
| Hard | 1.062 | 0.868 |

Tokens per verified success divides all reported tokens, including unsuccessful attempts, by the number of verified successes. It is not a price or billing estimate; token accounting can differ between model providers.

## Frozen source provenance

All displayed counts are checked against the saved paired records. Intervals and token ratios are copied from the saved summary, not recomputed. The shareable figure-5-data.json contains only approved aggregates; it contains no Hard task IDs or per-task outcomes.

`offline-summary.json` SHA-256: `dfadc34f3fa62642e59ec4c0f418e1af3b083c79b1aa38c3983e19ddae029437`

`offline-pairs.json` SHA-256: `86d2320eef791d4a3bd9fa310f886edba435f8f51bde69bafbed808a59b67760`

