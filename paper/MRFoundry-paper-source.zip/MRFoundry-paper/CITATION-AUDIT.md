# Citation audit — current MRI reporting revision

The independent MRI-focused reviews checked sequence/simulation claims, reconstruction/data conventions, and evaluation-method reporting against retained evidence and relevant primary sources. This delta removes an unsupported adapter assertion, clarifies the simulated phantom and trajectory scale, corrects two SI artifact/QC descriptions, and defines the control arm precisely. The source-code and archive distinctions remain explicit. All 48 cited keys and the bibliography bytes are unchanged. No new scientific workflows were run.

The previous metadata and claim reviews below remain historical evidence, with their original access limitations. The current input bindings are:

| File | SHA-256 |
|---|---|
| `manuscript.md` | `11c4db7b800371e2c850f8fe3b2f70f2e350eacd529130977e48c1e894259d47` |
| `manuscript-template.md` | `11c4db7b800371e2c850f8fe3b2f70f2e350eacd529130977e48c1e894259d47` |
| `references.bib` | `1f112dd7e9aa9a9362d84115d272ba1ae68062e9a9efc268be63ffb5dbdb5c73` |
| `figure-manifest.json` | `97802aa427f4c8d64f51901a60f0422fa8a674d5666ba3d1963063c7f7c98dd9` |
| `tables.json` | `e3cfcf36bde1b2ff8ff800874fcfe63722950438ef0a0e8904d2aaeddf3a90a2` |
| `latex/MRM-AMA-compatible.bst` | `8a9cf5489611b64646df96471135c587eb301365e564c84b417ab55eabc8c87f` |
| `latex/MRM-AMA.bst` | `0b455d74816e5185010415b75c949faa8f1ff57d11faa8f4c49734593099c749` |

---

# Citation audit — current expanded manuscript

The expanded manuscript received an independent claim-scope review against the pinned toolbox guidance, contribution implementation, saved demonstration evidence and benchmark records. All **39 main-text citation keys and 48 total cited keys** are unchanged; bibliography bytes are preserved. Existing primary-source metadata checks and access limitations remain applicable. This delta review does not claim that every full text was reopened.

New explanations of skill routing, memory revalidation, public contribution, the purpose of individual demonstration checks, and the benchmark procedure are supported by the inspected records. The statement about repository checks was narrowed: they validate structure and look for broken links, rather than establish universal source accessibility. The seven Core model increases and three unchanged totals match Table 2. The L1-versus-initial-SENSE magnitude comparison retains the adverse zero-filled comparison and unresolved measurement residuals. Sequence construction remains distinct from later skill retrieval; the acquired-support lesson does not invent a corrected 256-line calculation.

No material citation finding remains in this reviewed delta. Figure captions and quantitative data are unchanged; Table 2 labels are shortened to “With MRFoundry.” The JSON binds the current manuscript, bibliography, captions, tables and bibliography styles. Earlier bound inputs and review history below are retained as provenance, not claims about the current file hashes.

## Current bound inputs

| File | SHA-256 |
|---|---|
| `manuscript.md` | `2625588d95262f50aa101c47db3fce1ccff47145d293f7450c1842ac063bdd3c` |
| `manuscript-template.md` | `2625588d95262f50aa101c47db3fce1ccff47145d293f7450c1842ac063bdd3c` |
| `references.bib` | `1f112dd7e9aa9a9362d84115d272ba1ae68062e9a9efc268be63ffb5dbdb5c73` |
| `figure-manifest.json` | `11f53e55c98b7139c2a99c5444a74bf5150d41f119973e1a59b22e27f772bcf6` |
| `tables.json` | `e345407b830932870b49a1cf4347192e58b9d67b76dd568f92d0d26cf97de23d` |
| `latex/MRM-AMA-compatible.bst` | `8a9cf5489611b64646df96471135c587eb301365e564c84b417ab55eabc8c87f` |
| `latex/MRM-AMA.bst` | `0b455d74816e5185010415b75c949faa8f1ff57d11faa8f4c49734593099c749` |

---

# Preserved earlier citation audit

Completed on 3 November 2026. All **48 cited references** in the main manuscript, five figure captions and two tables were reviewed against primary sources; six uncited bibliography entries were excluded. The audit found no wrong paper or DOI and no remaining material unsupported claim in the revised prose. Source-access limits below remain; this is not a claim that every full text was freely accessible.

The earlier A/B audits used v50 PDF numbers. This resolution matches **citation keys**, because the revised Introduction may change v51 numbering.

## Post-review delta: condensed manuscript

An independent review on 3 November 2026 compared the frozen round-1 manuscript, five captions and two tables with the current condensed text. **All 48 citation keys remain**, with no additions or removals: 39 occur in main text, 15 in captions and 18 in tables (overlapping sets). Tables and bibliography are byte-identical; captions 1–2 are unchanged and 3–5 are condensed. Main/template bytes now match. No reviewer reports were accessed.

- **Agent4MR and BCER:** freshly re-opened author abstracts support the narrow sequence-validation and long-workflow/artifact-binding descriptions. No superiority or exhaustive novelty claim is attributed to them. See [Agent4MR](https://arxiv.org/abs/2604.13282) and [BCER](https://arxiv.org/abs/2605.29163).
- **HDF5 and MRI conventions:** h5py supports array/HDF5 inspection; the separately cited, pinned M4Raw H5 contract supports axes and acquired support. The [official h5py documentation](https://docs.h5py.org/en/stable/) was re-opened; the initial audit's retained primary M4Raw contract was read again. No MRI convention is attributed to h5py.
- **Methods and guidance:** software citations retain tool/algorithm roles. Actual agent actions, chosen parameters, negative reconstruction outcome and later-only sequence audit remain supported by saved records. Memory reuse and shared-contribution benefits stay unevaluated; Self-Refine/Reflexion remain conceptual comparisons.
- **Evaluation:** the frozen-source citation identifies code, while trial chronology, restart counts and changing resources depend on historical evidence. Condensation preserves the skills-plus-discovery intervention, unequal Hard cohorts and private-data limits. Saved intervals are not recomputed; secondary unclustered tests move to SI.
- **New availability statement:** the [public paper evidence directory](https://github.com/KeWang0622/MRFoundry/tree/main/paper/evidence) and its README, demonstration manifest and historical execution manifest were retrieved through the GitHub connector. They support the stated archival content and explicitly disclose omitted data and reproduction gaps; this is not a claim of a tested portable reproduction or an archival DOI.

**No material new unsupported citation claim was found.** This delta review does not repeat all initial metadata checks or claim unrestricted full-text access. The original per-reference access limits below still apply. No main prose, caption, table, bibliography, BST or scientific data was edited by this delta reviewer; only the root-authorized main-to-template synchronization and the audit records changed. No compile or scientific computation was run.

Initial JSON audit SHA-256: `20e84ae74ebfa2ab0b65c2d6531d76a3e00681376b8bc0e3e5236d19e1cf7315`.<br>
Initial Markdown audit SHA-256: `1f97857e6bf63167caaeeba68c3740df7a7f38ce69a19e18f0049e80ebedcccf`.
The JSON retains the entire initial input-hash map separately from the current bindings.

### Earlier revision-51 bound inputs after delta review

| File | SHA-256 |
|---|---|
| `manuscript.md` | `252dc12523985561860e469cddec50eac73df5a9398c3e372c4b3c3921bceedd` |
| `manuscript-template.md` | `252dc12523985561860e469cddec50eac73df5a9398c3e372c4b3c3921bceedd` |
| `references.bib` | `1f112dd7e9aa9a9362d84115d272ba1ae68062e9a9efc268be63ffb5dbdb5c73` |
| `figure-manifest.json` | `608abd0abfbb1f2f99bc74893578624a01705aca818cdaa382303ad94eb4242b` |
| `tables.json` | `d9b350ad06ddc68ed7c78d08a31e1550583f1e7160070693801d5d49bb077fb9` |
| `latex/MRM-AMA-compatible.bst` | `8a9cf5489611b64646df96471135c587eb301365e564c84b417ab55eabc8c87f` |
| `latex/MRM-AMA.bst` | `0b455d74816e5185010415b75c949faa8f1ff57d11faa8f4c49734593099c749` |

## Initial bibliography corrections applied

- Restored DIPY collective authorship; canonical CLAIM seven-author plus panel byline and Kahn Jr.; PyPulseq full names and Vaughan Jr. following its PDF byline. The PyPulseq HTML/BibTeX suffix discrepancy is recorded.
- Normalized SciPy to 34 named authors plus its collective; completed the MICCAI 2020 venue and ESPIRiT title punctuation; retained BCER as an arXiv preprint without invented proceedings metadata.
- Identified the current MRI Agent Bench name while preserving the historical BlochBench preview title and tag. Made the exact evaluated MRFoundry commit URL visible in the reference; this does not announce a new public software version.
- Updated access dates only for sources verified on 3 November. Omitted unverified publication years from seven undated living/source documents: Claude Code loop, Claude Code skills, Codex skills, skills CLI, h5py, SigPy implementation and tutorial.
- Preserved surname particles and suffixes in the compatible BST, including **van der Walt** and **Vaughan Jr.**; corrected punctuation for a suffix and an undated note. Original template typography, citation order and author truncation are retained. The upstream BST is untouched.

## Initial revised-prose check

The abstract now presents MRFoundry first and keeps the benchmark secondary. General agent capabilities are supported by the cited agent papers and official documentation. The MRI demonstrations remain supervised examples without matched controls. Sequence construction is distinguished from its later skill audit, and the reconstruction does not claim better reference agreement.

The prior memory-guide over-attribution was removed: input digests remain an actual demonstration fact rather than a requirement attributed to the guide. Local-to-public contribution now cites both the memory guide and contribution policy. HDF5 inspection and MRI axis/support interpretation now have separate h5py and release-contract citations. Memory/RSI and community improvement remain proposed mechanisms, not measured benefits.

Core findings remain limited to the tested paired comparison; Hard uncertainty, unequal cohorts and private task materials remain explicit. No new unaudited citation or unsupported release claim was introduced.

## Verification and limits

The standalone all-48-reference compile completed with **zero BibTeX errors**, no missing-character/undefined-citation messages, and the correct name/commit text in the PDF. This is a bibliography check; integrated manuscript pagination and page review are performed separately.

- All 48 cited references received primary-source metadata and claim-scope review; this is not a claim of unrestricted full-text access for every reference.
- Coscientist and COBIDAS: direct publisher/PMC retrieval was blocked; publisher-indexed primary text plus deposited metadata were inspected.
- Bernstein textbook: publisher description and contents inspected, not the complete copyrighted book.
- BART: official project publication record verified; linked 2015 abstract PDF returned 404.
- Winkelmann: primary abstract and author-institution publication record verified; IEEE full text was not reopened.
- Chung: accessible publisher proof preceded final pagination; publisher-deposited metadata supplied final pagination. Basser accessible primary citation used initials.
- Living documentation and current main branches do not prove their historical October 28 state. Access dates updated only for sources retrieved on November 3; unverified publication years were removed from seven undated documents.
- Software/method references establish tool roles and attribution. Saved run evidence, rather than public citations alone, supports actual execution, parameters, outcomes, and chronology relative to private task opening.
- Six unused bibliography entries were excluded from this citation audit and remain byte-identical. New metadata review or a changed claim requires an updated audit.

## Source register

Numbers below are the audit baseline from v50, not a claim about final v51 ordering. Full key-based assessments, corrections, limits and hashes are in `citation-audit.json`.

| Baseline | Key | Primary source | Scope / access note |
|---:|---|---|---|
| 1 | `react` | [Primary source](https://arxiv.org/abs/2210.03629) | Primary metadata and claim scope checked. |
| 2 | `claudeloop` | [Primary source](https://code.claude.com/docs/en/how-claude-code-works) | Access/scope limit recorded in JSON. |
| 3 | `sweagent` | [Primary source](https://proceedings.neurips.cc/paper_files/paper/2024/hash/5a7c947568c1b1328ccc5230172e1e7c-Abstract-Conference.html) | Primary metadata and claim scope checked. |
| 4 | `datainterpreter` | [Primary source](https://aclanthology.org/2025.findings-acl.1016/) | Primary metadata and claim scope checked. |
| 5 | `coscientist` | [Primary source](https://www.nature.com/articles/s41586-023-06792-0) | Access/scope limit recorded in JSON. |
| 6 | `bernstein` | [Primary source](https://shop.elsevier.com/books/handbook-of-mri-pulse-sequences/bernstein/978-0-12-092861-3) | Access/scope limit recorded in JSON. |
| 7 | `agent4mr` | [Primary source](https://arxiv.org/abs/2604.13282) | Primary metadata and claim scope checked. |
| 8 | `bcer` | [Primary source](https://arxiv.org/abs/2605.29163) | Primary metadata and claim scope checked. |
| 9 | `mrfoundry` | [Primary source](https://github.com/KeWang0622/MRFoundry/blob/6e4408e61ebf073845c32d95eca083e21a5ed33a/README.md) | Primary metadata and claim scope checked. |
| 10 | `claudecode` | [Primary source](https://code.claude.com/docs/en/skills) | Access/scope limit recorded in JSON. |
| 11 | `codex` | [Primary source](https://learn.chatgpt.com/docs/build-skills) | Access/scope limit recorded in JSON. |
| 12 | `pypulseq` | [Primary source](https://joss.theoj.org/papers/10.21105/joss.01725) | PDF/HTML suffix discrepancy resolved in favor of PDF. |
| 13 | `koma` | [Primary source](https://onlinelibrary.wiley.com/doi/10.1002/mrm.29635) | Primary metadata and claim scope checked. |
| 14 | `sigpy` | [Primary source](https://cds.ismrm.org/protected/19MProceedings/PDFfiles/4819.html) | Primary metadata and claim scope checked. |
| 15 | `dipy` | [Primary source](https://www.frontiersin.org/journals/neuroinformatics/articles/10.3389/fninf.2014.00008/full) | Primary metadata and claim scope checked. |
| 16 | `memoryguide` | [Primary source](https://github.com/KeWang0622/MRFoundry/blob/6e4408e61ebf073845c32d95eca083e21a5ed33a/skills/mri-research/references/project-memory.md) | Digest-attribution issue resolved in prose. |
| 17 | `mrfoundryindex` | [Primary source](https://github.com/KeWang0622/MRFoundry/blob/6e4408e61ebf073845c32d95eca083e21a5ed33a/REFERENCES.md) | Primary metadata and claim scope checked. |
| 18 | `cobidas` | [Primary source](https://www.nature.com/articles/nn.4500) | Access/scope limit recorded in JSON. |
| 19 | `claim` | [Primary source](https://pubs.rsna.org/doi/10.1148/ryai.240300) | Primary metadata and claim scope checked. |
| 20 | `roemer` | [Primary source](https://onlinelibrary.wiley.com/doi/10.1002/mrm.1910160203) | Primary metadata and claim scope checked. |
| 21 | `pulseq` | [Primary source](https://onlinelibrary.wiley.com/doi/10.1002/mrm.26235) | Primary metadata and claim scope checked. |
| 22 | `sense` | [Primary source](https://onlinelibrary.wiley.com/doi/10.1002/(SICI)1522-2594(199911)42:5%3C952::AID-MRM16%3E3.0.CO;2-S) | Primary metadata and claim scope checked. |
| 23 | `espirit` | [Primary source](https://onlinelibrary.wiley.com/doi/10.1002/mrm.24751) | Primary metadata and claim scope checked. |
| 24 | `sparsemri` | [Primary source](https://onlinelibrary.wiley.com/doi/10.1002/mrm.21391) | Primary metadata and claim scope checked. |
| 25 | `bart` | [Primary source](https://mrirecon.codeberg.page/publications.html) | Access/scope limit recorded in JSON. |
| 26 | `fastmri` | [Primary source](https://pubs.rsna.org/doi/10.1148/ryai.2020190007) | Primary metadata and claim scope checked. |
| 27 | `varnet` | [Primary source](https://link.springer.com/chapter/10.1007/978-3-030-59713-9_7) | Primary metadata and claim scope checked. |
| 28 | `basser` | [Primary source](https://pmc.ncbi.nlm.nih.gov/articles/PMC1275686/) | Access/scope limit recorded in JSON. |
| 29 | `chungwls` | [Primary source](https://brainimaging.waisman.wisc.edu/~chung/asymmetry/wild.bootstrap.pdf) | Access/scope limit recorded in JSON. |
| 30 | `skillscli` | [Primary source](https://github.com/vercel-labs/skills/blob/main/README.md) | Access/scope limit recorded in JSON. |
| 31 | `toolsetup` | [Primary source](https://github.com/KeWang0622/MRFoundry/blob/6e4408e61ebf073845c32d95eca083e21a5ed33a/skills/mri-research/references/tool-setup.md) | Primary metadata and claim scope checked. |
| 32 | `contributing` | [Primary source](https://github.com/KeWang0622/MRFoundry/blob/6e4408e61ebf073845c32d95eca083e21a5ed33a/CONTRIBUTING.md) | Primary metadata and claim scope checked. |
| 33 | `numpy` | [Primary source](https://www.nature.com/articles/s41586-020-2649-2) | Primary metadata and claim scope checked. |
| 34 | `scipy` | [Primary source](https://www.nature.com/articles/s41592-019-0686-2) | Primary metadata and claim scope checked. |
| 35 | `matplotlib` | [Primary source](https://matplotlib.org/stable/project/citing.html) | Primary metadata and claim scope checked. |
| 36 | `winkelmann` | [Primary source](https://publikationen.bibliothek.kit.edu/1000006342) | Access/scope limit recorded in JSON. |
| 37 | `m4raw` | [Primary source](https://www.nature.com/articles/s41597-023-02181-4) | Primary metadata and claim scope checked. |
| 38 | `m4rawdata` | [Primary source](https://zenodo.org/records/8056074) | Primary metadata and claim scope checked. |
| 39 | `m4format` | [Primary source](https://huggingface.co/datasets/mylyu/M4Raw_brain/blob/v1.6.0/H5_FORMAT.md) | Access/scope limit recorded in JSON. |
| 40 | `h5py` | [Primary source](https://docs.h5py.org/) | Access/scope limit recorded in JSON. |
| 41 | `sigpydocs` | [Primary source](https://github.com/mikgroup/sigpy/blob/v0.1.27/sigpy/mri/app.py) | Access/scope limit recorded in JSON. |
| 42 | `pywavelets` | [Primary source](https://joss.theoj.org/papers/10.21105/joss.01237) | Primary metadata and claim scope checked. |
| 43 | `blochbenchtasks` | [Primary source](https://github.com/KeWang0622/MRIAgentBench/tree/main/families) | Access/scope limit recorded in JSON. |
| 44 | `blochbench` | [Primary source](https://github.com/KeWang0622/MRIAgentBench/releases/tag/core-v0.1.0) | Primary metadata and claim scope checked. |
| 45 | `mrfoundry014` | [Primary source](https://github.com/KeWang0622/MRFoundry/tree/bd49b9556146bcd70ab1026c52d67713f4cf2e7f) | Access/scope limit recorded in JSON. |
| 46 | `selfrefine` | [Primary source](https://proceedings.neurips.cc/paper_files/paper/2023/hash/91edff07232fb1b55a505a9e9f6c0ff3-Abstract-Conference.html) | Primary metadata and claim scope checked. |
| 47 | `reflexion` | [Primary source](https://proceedings.nips.cc/paper_files/paper/2023/hash/1b44b878bb782e6954cd888628510e90-Abstract-Conference.html) | Primary metadata and claim scope checked. |
| 48 | `mrfoundrytutorial` | [Primary source](https://kewang0622.github.io/slides/mrfoundry/) | Access/scope limit recorded in JSON. |

## Initial audit bound inputs (preserved baseline)

| File | SHA-256 |
|---|---|
| `manuscript.md` | `f014bda87bfeb778c561e5c26fe9b2bf548898893cb72ba3b0da40a6dae21078` |
| `manuscript-template.md` | `f014bda87bfeb778c561e5c26fe9b2bf548898893cb72ba3b0da40a6dae21078` |
| `references.bib` | `1f112dd7e9aa9a9362d84115d272ba1ae68062e9a9efc268be63ffb5dbdb5c73` |
| `figure-manifest.json` | `d598c782f95a87826e76ba8e6a6708e2c00218d6e0a830e753b76f443c921028` |
| `tables.json` | `d9b350ad06ddc68ed7c78d08a31e1550583f1e7160070693801d5d49bb077fb9` |
| `latex/MRM-AMA-compatible.bst` | `8a9cf5489611b64646df96471135c587eb301365e564c84b417ab55eabc8c87f` |
| `latex/MRM-AMA.bst` | `0b455d74816e5185010415b75c949faa8f1ff57d11faa8f4c49734593099c749` |

No model, reconstruction, grading, bootstrap or other scientific experiment was run for this audit. Figures, tables, frozen scientific data and main prose were not edited by this auditor.

Final display-description correction: Figure 5 caption now says the numeric boxes report the saved confidence intervals; bar lengths encode completion rates. This correction changes no citation keys, values or source-attribution roles. Exact current caption-manifest hash is bound in citation-audit.json.
